/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import { useState, useEffect } from 'react';
import { Tournament, Pair, PadelCategory, TournamentType, GroupMode, TournamentFormat, Match, Group, PlayoffBracket } from './types';
import CreateTournamentForm from './components/CreateTournamentForm';
import TournamentHeader from './components/TournamentHeader';
import PairsList from './components/PairsList';
import GroupStageView from './components/GroupStageView';
import PlayoffBracketView from './components/PlayoffBracketView';
import ScoreModal from './components/ScoreModal';
import RankingPlaceholder from './components/RankingPlaceholder';
import EditTournamentModal from './components/EditTournamentModal';
import { generateId, generateGroups, generateInitialBracket, advanceBracketWinner } from './utils/tournamentSolver';
import { Trophy, Calendar, Users, Award, ShieldAlert, Folder, Plus } from 'lucide-react';

const LOCAL_STORAGE_KEY_LIST = 'padel_tournaments_list_v3';
const LOCAL_STORAGE_KEY_ACTIVE = 'padel_active_tournament_id_v3';

const INITIAL_PAIRS: Pair[] = [
  { id: '1', player1: 'Agustín Tapia', player2: 'Arturo Coello', registeredAt: Date.now() - 50000 },
  { id: '2', player1: 'Federico Chingotto', player2: 'Alejandro Galán', registeredAt: Date.now() - 40000 },
  { id: '3', player1: 'Martin Di Nenno', player2: 'Franco Stupaczuk', registeredAt: Date.now() - 30000 },
  { id: '4', player1: 'Juan Lebrón', player2: 'Francisco Navarro', registeredAt: Date.now() - 20000 },
  { id: '5', player1: 'Fernando Belasteguín', player2: 'Sanyo Gutiérrez', registeredAt: Date.now() - 10000 },
  { id: '6', player1: 'Jon Sanz', player2: 'Coki Nieto', registeredAt: Date.now() },
];

export default function App() {
  // Main tabs: "tournament" or "ranking"
  const [activeMainTab, setActiveMainTab] = useState<'tournament' | 'ranking'>('tournament');
  
  // Active stage inside Tournament tab: 'registration' | 'groups' | 'playoffs'
  const [tournamentStage, setTournamentStage] = useState<'registration' | 'groups' | 'playoffs'>('registration');

  // Tournaments lists states
  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [activeTournamentId, setActiveTournamentId] = useState<string | null>(null);
  const [isCreatingTournament, setIsCreatingTournament] = useState(false);
  const [editingTournament, setEditingTournament] = useState<Tournament | null>(null);

  // Derived state for the active tournament
  const tournament = tournaments.find((t) => t.id === activeTournamentId) || null;

  // Score modal state
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);

  // Load state from LocalStorage on mount
  useEffect(() => {
    try {
      const savedList = localStorage.getItem(LOCAL_STORAGE_KEY_LIST);
      const savedActiveId = localStorage.getItem(LOCAL_STORAGE_KEY_ACTIVE);
      
      let list: Tournament[] = [];
      if (savedList) {
        list = JSON.parse(savedList);
      }
      
      if (list.length === 0) {
        // Bootstrap with a nice pre-populated draft tournament so they see immediate action
        const mock: Tournament = {
          id: 'draft_tournament',
          name: 'Open Sunset Padel Cup 🌵',
          category: 'Sexta',
          type: 'CABALLEROS',
          groupMode: '3 parejas',
          format: 'Largo',
          pairs: INITIAL_PAIRS,
          stage: 'registration',
          groups: [],
          bracket: null,
        };
        list = [mock];
      }
      
      setTournaments(list);
      
      let activeId = savedActiveId;
      if (!activeId || !list.some((t) => t.id === activeId)) {
        activeId = list[0].id;
      }
      
      setActiveTournamentId(activeId);
      localStorage.setItem(LOCAL_STORAGE_KEY_ACTIVE, activeId);
      
      const activeTourney = list.find((t) => t.id === activeId);
      if (activeTourney) {
        setTournamentStage(activeTourney.stage || 'registration');
      }
    } catch (e) {
      console.error('Error loading tournaments from localStorage', e);
    }
  }, []);

  // Save to list
  const saveTournaments = (updatedList: Tournament[]) => {
    setTournaments(updatedList);
    localStorage.setItem(LOCAL_STORAGE_KEY_LIST, JSON.stringify(updatedList));
  };

  // Safe save updates to the current active tournament (retains multi-tournament structure)
  const saveTournament = (updated: Tournament | null) => {
    if (updated) {
      const exists = tournaments.some((t) => t.id === updated.id);
      let list = [];
      if (exists) {
        list = tournaments.map((t) => (t.id === updated.id ? updated : t));
      } else {
        list = [...tournaments, updated];
      }
      saveTournaments(list);
      setActiveTournamentId(updated.id);
      localStorage.setItem(LOCAL_STORAGE_KEY_ACTIVE, updated.id);
    } else {
      if (activeTournamentId) {
        const list = tournaments.filter((t) => t.id !== activeTournamentId);
        saveTournaments(list);
        if (list.length > 0) {
          setActiveTournamentId(list[0].id);
          localStorage.setItem(LOCAL_STORAGE_KEY_ACTIVE, list[0].id);
          setTournamentStage(list[0].stage || 'registration');
        } else {
          setActiveTournamentId(null);
          localStorage.removeItem(LOCAL_STORAGE_KEY_ACTIVE);
          setTournamentStage('registration');
        }
      }
    }
  };

  // Create a new tournament
  const handleCreateTournament = (
    name: string,
    category: PadelCategory,
    type: TournamentType,
    groupMode: GroupMode,
    format: TournamentFormat
  ) => {
    const newTournament: Tournament = {
      id: `tournament_${generateId()}`,
      name,
      category,
      type,
      groupMode,
      format,
      pairs: [],
      stage: 'registration',
      groups: [],
      bracket: null,
    };
    const list = [...tournaments, newTournament];
    saveTournaments(list);
    setActiveTournamentId(newTournament.id);
    localStorage.setItem(LOCAL_STORAGE_KEY_ACTIVE, newTournament.id);
    setTournamentStage('registration');
    setIsCreatingTournament(false);
  };

  // Delete current tournament
  const handleDeleteTournament = () => {
    saveTournament(null);
    setTournamentStage('registration');
  };

  // Add registered Pair
  const handleAddPair = (player1: string, player2: string) => {
    if (!tournament) return;
    const newPair: Pair = {
      id: `pair_${generateId()}`,
      player1,
      player2,
      registeredAt: Date.now(),
    };
    const updated: Tournament = {
      ...tournament,
      pairs: [...tournament.pairs, newPair],
    };
    saveTournament(updated);
  };

  // Remove pair
  const handleRemovePair = (id: string) => {
    if (!tournament) return;
    const updated: Tournament = {
      ...tournament,
      pairs: tournament.pairs.filter((p) => p.id !== id),
    };
    saveTournament(updated);
  };

  // Reorder registered pairs
  const handleReorderPairs = (newPairs: Pair[]) => {
    if (!tournament) return;
    const updated: Tournament = {
      ...tournament,
      pairs: newPairs,
    };
    saveTournament(updated);
  };

  // Set group mode toggle directly
  const handleSetGroupMode = (mode: GroupMode) => {
    if (!tournament) return;
    const updated: Tournament = {
      ...tournament,
      groupMode: mode,
    };
    saveTournament(updated);
  };

  // Generate Stage Groups & Matches
  const handleGenerateGroups = () => {
    if (!tournament) return;
    const generated = generateGroups(tournament.pairs, tournament.groupMode);
    const updated: Tournament = {
      ...tournament,
      groups: generated,
      stage: 'groups',
      // Reset bracket to ensure complete sync
      bracket: null,
    };
    setTournamentStage('groups');
    saveTournament(updated);
  };

  // Set Stage directly (navigation)
  const handleSetStage = (stage: 'registration' | 'groups' | 'playoffs') => {
    setTournamentStage(stage);
    if (tournament) {
      saveTournament({
        ...tournament,
        stage,
      });
    }
  };

  // Prepare Playoff Bracket setup
  const handleGenerateBracket = (size: '2' | '4' | '8' | '16') => {
    if (!tournament) return;
    const bracket = generateInitialBracket(size, tournament.groups, tournament.pairs);
    const updated: Tournament = {
      ...tournament,
      bracket,
      stage: 'playoffs',
    };
    setTournamentStage('playoffs');
    saveTournament(updated);
  };

  // Reset bracket
  const handleResetBracket = () => {
    if (!tournament) return;
    if (confirm('¿Deseas reiniciar el cuadro eliminatorio actual? Se perderán todos los resultados de playoffs cargados hasta el momento.')) {
      const updated: Tournament = {
        ...tournament,
        bracket: null,
      };
      saveTournament(updated);
    }
  };

  // Manual seeding swap inside bracket
  const handleUpdateMatchSeeding = (
    roundName: string,
    matchId: string,
    teamKey: 'teamAId' | 'teamBId',
    pairId: string
  ) => {
    if (!tournament || !tournament.bracket) return;
    const nextBracket = { ...tournament.bracket };
    const roundIdx = nextBracket.rounds.findIndex((r) => r.name === roundName);
    if (roundIdx !== -1) {
      const matchIdx = nextBracket.rounds[roundIdx].matches.findIndex((m) => m.id === matchId);
      if (matchIdx !== -1) {
        nextBracket.rounds[roundIdx].matches[matchIdx][teamKey] = pairId;
        saveTournament({
          ...tournament,
          bracket: nextBracket,
        });
      }
    }
  };

  // Record completed match scores
  const handleSaveMatchScore = (
    set1: { teamA: number; teamB: number },
    set2: { teamA: number; teamB: number },
    set3: { teamA: number; teamB: number },
    winnerId: string | null
  ) => {
    if (!tournament || !selectedMatch) return;

    // Check if it belongs to group stage or bracket stage
    const isPlayoff = selectedMatch.id.startsWith('playoff');

    if (isPlayoff && tournament.bracket) {
      // Propagation of bracket results detailing set scores
      const nextBracket = advanceBracketWinner(
        tournament.bracket,
        selectedMatch.id,
        winnerId,
        set1,
        set2,
        set3
      );

      saveTournament({
        ...tournament,
        bracket: nextBracket,
      });
    } else {
      // It's a standard group stage match
      const updatedGroups = tournament.groups.map((g) => {
        const containsMatch = g.matches.some((m) => m.id === selectedMatch.id);
        if (!containsMatch) return g;

        return {
          ...g,
          matches: g.matches.map((m) => {
            if (m.id !== selectedMatch.id) return m;
            return {
              ...m,
              set1,
              set2,
              set3,
              winnerId,
              played: true,
            };
          }),
        };
      });

      saveTournament({
        ...tournament,
        groups: updatedGroups,
      });
    }

    setSelectedMatch(null);
  };

  // Check if at least some matches are played so they can advance to playoffs if preferred
  const canAdvanceToPlayoffs = tournament ? tournament.groups.length > 0 : false;

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col font-sans selection:bg-lime-500 selection:text-slate-900">
      
      {/* Top Banner Branding Header */}
      <header className="bg-slate-900 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <div className="w-5.5 h-5.5 bg-black border border-slate-800 rounded flex items-center justify-center flex-shrink-0" id="padelnuestro_logo">
              <svg viewBox="0 0 100 100" className="w-3.5 h-3.5" stroke="currentColor" fill="none" strokeWidth="6" strokeLinecap="round">
                <circle cx="50" cy="50" r="41" stroke="white" strokeWidth="8" />
                <path d="M 29,20 A 40,40 0 0,0 29,80" stroke="white" strokeWidth="8" />
                <path d="M 71,20 A 40,40 0 0,1 71,80" stroke="white" strokeWidth="8" />
              </svg>
            </div>
            <div>
              <span className="text-white font-extrabold text-[10px] sm:text-xs tracking-tight block uppercase leading-none">
                PADELNUESTRO
              </span>
              <span className="text-[7px] sm:text-[8px] uppercase font-sans tracking-wider text-lime-400 block mt-0.5 font-bold leading-none">
                Gestión Integral de Ranking y Torneos
              </span>
            </div>
          </div>

          {/* Tab Navigation Menu aligned to bottom */}
          <nav className="flex space-x-1 h-full items-end" aria-label="Tabs principales">
            <button
              onClick={() => setActiveMainTab('tournament')}
              className={`px-5 py-3 text-xs sm:text-sm font-bold transition-all rounded-t-lg border-b-0 mt-4 leading-none ${
                activeMainTab === 'tournament'
                  ? 'bg-slate-100 text-slate-900 font-extrabold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800 font-medium'
              }`}
            >
              Gestión de Torneos
            </button>
            <button
              onClick={() => setActiveMainTab('ranking')}
              className={`px-5 py-3 text-xs sm:text-sm font-bold transition-all rounded-t-lg border-b-0 mt-4 leading-none ${
                activeMainTab === 'ranking'
                  ? 'bg-slate-100 text-slate-900 font-extrabold'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800 font-medium'
              }`}
            >
              Ranking de Jugadores
            </button>
          </nav>

        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
        
        {activeMainTab === 'ranking' ? (
          // Tab "Ranking de Jugadores" which contains nothing (as instructed: 'que no contenga nada')
          <RankingPlaceholder />
        ) : (
          // Tab "Gestión de Torneos" (Tournament management)
          // Tab "Gestión de Torneos" (Tournament management)
          <div className="space-y-8 animate-fade-in">
            {/* COMPACT TOURNAMENT LIST & ACTION HEADER */}
            <div className="space-y-3">
              {/* List Header and Create Button */}
              <div className="flex justify-between items-center bg-slate-900 text-slate-100 p-3 px-4 rounded-xl shadow-xs">
                <span className="text-[11px] sm:text-xs font-black uppercase tracking-wider text-slate-300">
                  📁 Mis Torneos ({tournaments.length})
                </span>
                <button
                  type="button"
                  onClick={() => setIsCreatingTournament(!isCreatingTournament)}
                  className="flex items-center gap-1 text-[10px] bg-lime-500 hover:bg-lime-450 active:scale-95 text-slate-950 font-black py-1 sm:py-1.5 px-3 rounded-lg transition shadow-2xs cursor-pointer uppercase tracking-wider"
                >
                  <Plus className="w-3 h-3" />
                  <span>Crear Nuevo Torneo</span>
                </button>
              </div>

              {/* Toggleable Creation Block inside the main directory */}
              {isCreatingTournament && (
                <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl relative shadow-3xs animate-scale-up">
                  <div className="flex justify-between items-center mb-3 border-b border-slate-200/50 pb-2">
                    <h4 className="text-[10px] font-black uppercase text-slate-600 tracking-wider">Formulario de Creación</h4>
                    <button 
                      type="button" 
                      onClick={() => setIsCreatingTournament(false)} 
                      className="text-[10px] text-slate-405 hover:text-slate-800 font-extrabold cursor-pointer"
                    >
                      Cancelar
                    </button>
                  </div>
                  <CreateTournamentForm onCreate={handleCreateTournament} />
                </div>
              )}

              {/* Compact list */}
              {tournaments.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {tournaments.map((t, index) => {
                    const isActive = t.id === activeTournamentId;
                    return (
                      <div
                        key={t.id}
                        onClick={() => {
                          setActiveTournamentId(t.id);
                          localStorage.setItem(LOCAL_STORAGE_KEY_ACTIVE, t.id);
                          setTournamentStage(t.stage || 'registration');
                        }}
                        className={`group flex items-center justify-between p-2.5 sm:p-3 rounded-xl border transition-all cursor-pointer gap-3 ${
                          isActive
                            ? 'border-lime-500 bg-lime-500/5 ring-1 ring-lime-500/25 shadow-3xs'
                            : 'bg-white hover:bg-slate-50 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 flex-1 min-w-0">
                          {/* Number List Indicator */}
                          <div className={`w-5.5 h-5.5 rounded-full text-[10px] font-bold font-mono flex items-center justify-center flex-shrink-0 shadow-3xs ${
                            isActive ? 'bg-lime-500 text-slate-950' : 'bg-slate-100 group-hover:bg-white text-slate-600 border border-slate-200'
                          }`}>
                            {index + 1}
                          </div>

                          <div className="flex-1 min-w-0 leading-tight">
                            <h3 className="font-extrabold text-slate-900 group-hover:text-black text-xs sm:text-sm tracking-tight truncate">
                              {t.name}
                            </h3>

                            <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                              <span className="text-[8px] font-extrabold font-mono text-lime-700 bg-lime-500/10 px-1.5 py-0.5 rounded uppercase leading-none">
                                🏆 {t.category}
                              </span>
                              <span className="text-[8px] font-extrabold font-mono text-cyan-700 bg-cyan-500/10 px-1.5 py-0.5 rounded uppercase leading-none">
                                {t.type === 'CABALLEROS' ? 'Caballeros' : t.type === 'DAMAS' ? 'Damas' : 'Mixto'}
                              </span>
                              <span className="text-[8px] font-extrabold font-mono text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded uppercase leading-none">
                                👥 {t.groupMode}
                              </span>
                              <span className="text-[8px] font-mono text-slate-500 bg-slate-50 border border-slate-150 px-1.5 py-0.5 rounded leading-none">
                                Parejas: <strong className="text-slate-800 font-extrabold">{t.pairs.length}</strong>
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditingTournament(t);
                            }}
                            className="text-[9px] text-slate-700 hover:text-white bg-slate-100 hover:bg-slate-900 border border-slate-200 hover:border-slate-900 font-extrabold px-2.5 py-1 rounded-lg transition shadow-3xs cursor-pointer"
                          >
                            Editar
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="bg-white border border-slate-200 p-6 rounded-xl text-center text-slate-500 text-xs">
                  No tienes ningún torneo creado. Haz clic en "Crear Nuevo Torneo" arriba para empezar.
                </div>
              )}
            </div>

            {/* SELECTED TOURNAMENT DASHBOARD WORKFLOW */}
            {tournament ? (
              <div className="border-t border-slate-205 pt-6 mt-6 space-y-8 animate-fade-in">
                {/* Visual Status Indicator / Steps */}
                <TournamentHeader
                  tournament={tournament}
                  onDelete={handleDeleteTournament}
                  onEdit={() => setEditingTournament(tournament)}
                  activeStage={tournamentStage}
                  onSetStage={handleSetStage}
                />

                {/* Subsections based on tabs */}
                {tournamentStage === 'registration' && (
                  <PairsList
                    pairs={tournament.pairs}
                    groupMode={tournament.groupMode}
                    onAddPair={handleAddPair}
                    onRemovePair={handleRemovePair}
                    onReorderPairs={handleReorderPairs}
                    onSetGroupMode={handleSetGroupMode}
                  />
                )}

                {tournamentStage === 'groups' && (
                  <GroupStageView
                    groups={tournament.groups}
                    pairs={tournament.pairs}
                    onGenerateGroups={handleGenerateGroups}
                    onSelectMatch={setSelectedMatch}
                    onAdvanceToPlayoffs={() => handleSetStage('playoffs')}
                    canAdvance={canAdvanceToPlayoffs}
                    format={tournament.format}
                  />
                )}

                {tournamentStage === 'playoffs' && (
                  <PlayoffBracketView
                    bracket={tournament.bracket}
                    groups={tournament.groups}
                    pairs={tournament.pairs}
                    onGenerateBracket={handleGenerateBracket}
                    onSelectMatch={setSelectedMatch}
                    onUpdateMatchSeeding={handleUpdateMatchSeeding}
                    onResetBracket={handleResetBracket}
                  />
                )}
              </div>
            ) : (
              <div className="bg-slate-50 border border-slate-200 border-dashed p-6 rounded-2xl text-center text-slate-500 text-xs font-medium">
                Selecciona un torneo de la lista anterior para ver su gestión (Inscriptos, Grupos, Playoffs).
              </div>
            )}
          </div>
        )}

      </main>

      {/* SCORE REGISTER MODAL */}
      {selectedMatch && tournament && (
        <ScoreModal
          match={selectedMatch}
          pairs={tournament.pairs}
          format={tournament.format || 'Largo'}
          onClose={() => setSelectedMatch(null)}
          onSave={handleSaveMatchScore}
        />
      )}

      {/* EDIT TOURNAMENT METADATA MODAL */}
      {editingTournament && (
        <EditTournamentModal
          tournament={editingTournament}
          onClose={() => setEditingTournament(null)}
          onSave={(newName, newCategory, newType, newGroupMode, newFormat) => {
            const updated = tournaments.map((t) => {
              if (t.id === editingTournament.id) {
                return {
                  ...t,
                  name: newName,
                  category: newCategory,
                  type: newType,
                  groupMode: newGroupMode,
                  format: newFormat,
                };
              }
              return t;
            });
            saveTournaments(updated);
            setEditingTournament(null);
          }}
          onDelete={() => {
            const updated = tournaments.filter((tm) => tm.id !== editingTournament.id);
            saveTournaments(updated);
            if (activeTournamentId === editingTournament.id) {
              if (updated.length > 0) {
                setActiveTournamentId(updated[0].id);
                localStorage.setItem(LOCAL_STORAGE_KEY_ACTIVE, updated[0].id);
                setTournamentStage(updated[0].stage || 'registration');
              } else {
                setActiveTournamentId(null);
                localStorage.removeItem(LOCAL_STORAGE_KEY_ACTIVE);
                setTournamentStage('registration');
              }
            }
            setEditingTournament(null);
          }}
        />
      )}

      {/* Simple elegant layout footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-500 py-6 text-center text-xs">
        <p>© 2026 PADELNUESTRO - Gestión Integral de Ranking y Torneos. Todos los derechos reservados.</p>
      </footer>

    </div>
  );
}
