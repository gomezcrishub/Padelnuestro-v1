import { useState, FormEvent } from 'react';
import { PadelCategory, TournamentType, GroupMode, TournamentFormat } from '../types';
import { Trophy, Award, Users, Hourglass } from 'lucide-react';

interface CreateTournamentFormProps {
  onCreate: (name: string, category: PadelCategory, type: TournamentType, groupMode: GroupMode, format: TournamentFormat) => void;
}

const CATEGORIES_PRESETS = [
  'Octava',
  'Séptima',
  'Sexta',
  'Quinta',
  'Cuarta',
  'Tercera',
  'LIBRE',
  'OTRA',
];

export default function CreateTournamentForm({ onCreate }: CreateTournamentFormProps) {
  const [name, setName] = useState('');
  const [selectedPreset, setSelectedPreset] = useState('Sexta');
  const [customCategory, setCustomCategory] = useState('');
  const [type, setType] = useState<TournamentType>('CABALLEROS');
  const [groupMode, setGroupMode] = useState<GroupMode>('4 parejas');
  const [format, setFormat] = useState<TournamentFormat>('Largo');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const finalCategory = selectedPreset === 'OTRA' ? customCategory.trim() : selectedPreset;
    if (!finalCategory) return;
    onCreate(name.trim(), finalCategory, type, groupMode, format);
  };

  return (
    <div className="max-w-xl mx-auto bg-white border border-slate-200 p-6 sm:p-8 rounded-3xl shadow-sm animate-scale-up" id="create_tournament_card">
      <div className="text-center space-y-2 mb-8">
        <div className="w-16 h-16 rounded-full bg-lime-500/10 border border-lime-500/20 flex items-center justify-center text-3xl mx-auto text-lime-600 font-bold mb-4">
          🎾
        </div>
        <h2 className="text-2xl font-extrabold text-slate-950 font-sans tracking-tight">Crear Nuevo Torneo</h2>
        <p className="text-slate-500 text-sm max-w-sm mx-auto">
          Configura los detalles iniciales de tu torneo de pádel para comenzar a registrar jugadores.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* Name Input */}
        <div>
          <label className="block text-slate-700 text-xs font-bold uppercase tracking-wider mb-2 font-mono">
            Nombre del Torneo
          </label>
          <input
            type="text"
            required
            autoFocus
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Ej: Open de Otoño - Complejo Padel"
            className="w-full bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-lime-500 focus:ring-1 focus:ring-lime-500 transition"
          />
        </div>

        {/* Category Selector */}
        <div>
          <label className="block text-slate-700 text-xs font-bold uppercase tracking-wider mb-2 font-mono flex items-center gap-1.5">
            <Award className="w-4 h-4 text-lime-600" />
            Categoría del Torneo
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {CATEGORIES_PRESETS.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedPreset(cat)}
                className={`py-2 px-3 text-xs font-semibold rounded-lg border transition ${
                  selectedPreset === cat
                    ? 'bg-slate-800 border-slate-900 text-white shadow-sm font-bold'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {selectedPreset === 'OTRA' && (
            <div className="mt-3 animate-fade-in">
              <label className="block text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1 font-mono">
                Escribe la categoría personalizada:
              </label>
              <input
                type="text"
                required
                value={customCategory}
                onChange={(e) => setCustomCategory(e.target.value)}
                placeholder="Ej: Segunda, Iniciados, Súper 50..."
                className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none focus:border-lime-500 focus:ring-1 focus:ring-lime-500 transition"
              />
            </div>
          )}
        </div>

        {/* Tipo (CABALLEROS / DAMAS / MIXTO) */}
        <div>
          <label className="block text-slate-700 text-xs font-bold uppercase tracking-wider mb-2 font-mono flex items-center gap-1.5">
            <Trophy className="w-4 h-4 text-lime-600" />
            Rama / Género (Tipo)
          </label>
          <div className="grid grid-cols-3 gap-2 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setType('CABALLEROS')}
              className={`py-2 px-2 text-xs font-bold rounded-lg uppercase tracking-wide transition ${
                type === 'CABALLEROS'
                  ? 'bg-white border border-slate-200 text-slate-900 font-extrabold shadow-sm'
                  : 'text-slate-500 hover:text-slate-950'
              }`}
            >
              CABALLEROS
            </button>
            <button
              type="button"
              onClick={() => setType('DAMAS')}
              className={`py-2 px-2 text-xs font-bold rounded-lg uppercase tracking-wide transition ${
                type === 'DAMAS'
                  ? 'bg-white border border-slate-200 text-slate-900 font-extrabold shadow-sm'
                  : 'text-slate-500 hover:text-slate-950'
              }`}
            >
              DAMAS
            </button>
            <button
              type="button"
              onClick={() => setType('MIXTO')}
              className={`py-2 px-2 text-xs font-bold rounded-lg uppercase tracking-wide transition ${
                type === 'MIXTO'
                  ? 'bg-white border border-slate-200 text-slate-900 font-extrabold shadow-sm'
                  : 'text-slate-500 hover:text-slate-950'
              }`}
            >
              MIXTO
            </button>
          </div>
        </div>

        {/* Modalidad de grupos pre-selector */}
        <div>
          <label className="block text-slate-700 text-xs font-bold uppercase tracking-wider mb-2 font-mono flex items-center gap-1.5">
            <Users className="w-4 h-4 text-lime-600" />
            Modalidad Predeterminada de Grupos
          </label>
          <div className="grid grid-cols-2 gap-3 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setGroupMode('3 parejas')}
              className={`py-2 px-4 text-xs font-bold rounded-lg transition ${
                groupMode === '3 parejas'
                  ? 'bg-white border border-slate-200 text-slate-900 font-extrabold shadow-sm'
                  : 'text-slate-500 hover:text-slate-955'
              }`}
            >
              3 Parejas por Grupo
            </button>
            <button
              type="button"
              onClick={() => setGroupMode('4 parejas')}
              className={`py-2 px-4 text-xs font-bold rounded-lg transition ${
                groupMode === '4 parejas'
                  ? 'bg-white border border-slate-200 text-slate-900 font-extrabold shadow-sm'
                  : 'text-slate-500 hover:text-slate-955'
              }`}
            >
              4 Parejas por Grupo
            </button>
          </div>
        </div>

        {/* Formato de partidos */}
        <div>
          <label className="block text-slate-700 text-xs font-bold uppercase tracking-wider mb-2 font-mono flex items-center gap-1.5">
            <Hourglass className="w-4 h-4 text-lime-600" />
            Formato de Partidos
          </label>
          <div className="grid grid-cols-2 gap-3 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setFormat('Largo')}
              className={`py-2 px-4 text-xs font-bold rounded-lg transition text-center flex flex-col items-center justify-center ${
                format === 'Largo'
                  ? 'bg-white border border-slate-200 text-slate-900 font-extrabold shadow-sm'
                  : 'text-slate-500 hover:text-slate-950'
              }`}
            >
              <span>Largo (3 Sets)</span>
              <span className="text-[9px] font-normal opacity-70">Mejor de 3 sets (Super Tiebreak)</span>
            </button>
            <button
              type="button"
              onClick={() => setFormat('Mini')}
              className={`py-2 px-4 text-xs font-bold rounded-lg transition text-center flex flex-col items-center justify-center ${
                format === 'Mini'
                  ? 'bg-white border border-slate-200 text-slate-900 font-extrabold shadow-sm'
                  : 'text-slate-500 hover:text-slate-955'
              }`}
            >
              <span>Mini (1 Set)</span>
              <span className="text-[9px] font-normal opacity-70">A un solo set directo</span>
            </button>
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-slate-900 hover:bg-slate-800 text-white font-extrabold py-3.5 px-4 rounded-xl text-sm transition tracking-wide shadow-md mt-2 active:scale-95 cursor-pointer text-center uppercase"
        >
          INICIAR TORNEO 🚀
        </button>

      </form>
    </div>
  );
}
