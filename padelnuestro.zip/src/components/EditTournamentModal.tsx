import { useState, FormEvent } from 'react';
import { Tournament, TournamentType, GroupMode, TournamentFormat } from '../types';
import { Trophy, Award, Users, Hourglass, X, Trash2 } from 'lucide-react';

interface EditTournamentModalProps {
  tournament: Tournament;
  onClose: () => void;
  onSave: (
    name: string,
    category: string,
    type: TournamentType,
    groupMode: GroupMode,
    format: TournamentFormat
  ) => void;
  onDelete?: () => void;
}

const CATEGORIES_PRESETS = [
  'Octava',
  'Séptima',
  'Sexta',
  'Quinta',
  'Cuarta',
  'Tercera',
  'LIBRE',
  'OTRA',
];

export default function EditTournamentModal({
  tournament,
  onClose,
  onSave,
  onDelete,
}: EditTournamentModalProps) {
  const [name, setName] = useState(tournament.name);
  
  // Detect if previous category was a custom one
  const isPreset = CATEGORIES_PRESETS.filter(c => c !== 'OTRA').includes(tournament.category);
  const [selectedPreset, setSelectedPreset] = useState(isPreset ? tournament.category : 'OTRA');
  const [customCategory, setCustomCategory] = useState(isPreset ? '' : tournament.category);

  const [type, setType] = useState<TournamentType>(tournament.type);
  const [groupMode, setGroupMode] = useState<GroupMode>(tournament.groupMode);
  const [format, setFormat] = useState<TournamentFormat>(tournament.format || 'Largo');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const finalCategory = selectedPreset === 'OTRA' ? customCategory.trim() : selectedPreset;
    if (!finalCategory) return;
    onSave(name.trim(), finalCategory, type, groupMode, format);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div 
        className="bg-white w-full max-w-xl rounded-3xl border border-slate-200 shadow-2xl overflow-hidden animate-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 p-5 sm:px-6">
          <div className="flex items-center gap-2">
            <span className="text-xl">⚙️</span>
            <h3 className="font-extrabold text-slate-950 text-base sm:text-lg">Editar Detalles del Torneo</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-450 hover:text-slate-800 hover:bg-slate-100/80 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-5 max-h-[80vh] overflow-y-auto pr-2">
          
          {/* Name Input */}
          <div>
            <label className="block text-slate-705 text-xs font-bold uppercase tracking-wider mb-2 font-mono">
              Nombre del Torneo
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-50 border border-slate-240 text-slate-900 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-lime-500 focus:ring-1 focus:ring-lime-500 transition"
              placeholder="Ej: Copa Master - Primavera"
            />
          </div>

          {/* Category Selector */}
          <div className="space-y-2">
            <label className="block text-slate-705 text-xs font-bold uppercase tracking-wider mb-1.5 font-mono flex items-center gap-1.5">
              <Award className="w-4 h-4 text-lime-600" />
              Categoría del Torneo
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {CATEGORIES_PRESETS.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedPreset(cat)}
                  className={`py-2 px-2.5 text-xs font-semibold rounded-lg border transition ${
                    selectedPreset === cat
                      ? 'bg-slate-800 border-slate-900 text-white shadow-sm font-bold'
                      : 'bg-slate-50 border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {selectedPreset === 'OTRA' && (
              <div className="mt-2.5 animate-fade-in">
                <label className="block text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1 font-mono">
                  Escribe la categoría personalizada:
                </label>
                <input
                  type="text"
                  required
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value)}
                  placeholder="Ej: Segunda, Iniciados, Senior..."
                  className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:border-lime-500"
                />
              </div>
            )}
          </div>

          {/* Tipo (CABALLEROS / DAMAS / MIXTO) */}
          <div>
            <label className="block text-slate-705 text-xs font-bold uppercase tracking-wider mb-2 font-mono flex items-center gap-1.5">
              <Trophy className="w-4 h-4 text-lime-600" />
              Rama / Género (Tipo)
            </label>
            <div className="grid grid-cols-3 gap-2 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
              <button
                type="button"
                onClick={() => setType('CABALLEROS')}
                className={`py-2 px-2 text-xs font-bold rounded-lg uppercase tracking-wide transition ${
                  type === 'CABALLEROS'
                    ? 'bg-white border border-slate-200 text-slate-900 font-extrabold shadow-sm'
                    : 'text-slate-500 hover:text-slate-950'
                }`}
              >
                CABALLEROS
              </button>
              <button
                type="button"
                onClick={() => setType('DAMAS')}
                className={`py-2 px-2 text-xs font-bold rounded-lg uppercase tracking-wide transition ${
                  type === 'DAMAS'
                    ? 'bg-white border border-slate-200 text-slate-950 font-extrabold shadow-sm'
                    : 'text-slate-500 hover:text-slate-950'
                }`}
              >
                DAMAS
              </button>
              <button
                type="button"
                onClick={() => setType('MIXTO')}
                className={`py-2 px-2 text-xs font-bold rounded-lg uppercase tracking-wide transition ${
                  type === 'MIXTO'
                    ? 'bg-white border border-slate-200 text-slate-955 font-extrabold shadow-sm'
                    : 'text-slate-500 hover:text-slate-950'
                }`}
              >
                MIXTO
              </button>
            </div>
          </div>

          {/* Modalidad de grupos */}
          <div>
            <label className="block text-slate-750 text-xs font-bold uppercase tracking-wider mb-2 font-mono flex items-center gap-1.5">
              <Users className="w-4 h-4 text-lime-600" />
              Modalidad de Grupos
            </label>
            <div className="grid grid-cols-2 gap-3 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
              <button
                type="button"
                onClick={() => setGroupMode('3 parejas')}
                className={`py-2 px-4 text-xs font-bold rounded-lg transition ${
                  groupMode === '3 parejas'
                    ? 'bg-white border border-slate-200 text-slate-900 font-extrabold shadow-sm'
                    : 'text-slate-500 hover:text-slate-955'
                }`}
              >
                3 Parejas por Grupo
              </button>
              <button
                type="button"
                onClick={() => setGroupMode('4 parejas')}
                className={`py-2 px-4 text-xs font-bold rounded-lg transition ${
                  groupMode === '4 parejas'
                    ? 'bg-white border border-slate-200 text-slate-900 font-extrabold shadow-sm'
                    : 'text-slate-500 hover:text-slate-955'
                }`}
              >
                4 Parejas por Grupo
              </button>
            </div>
          </div>

          {/* Formato de partidos */}
          <div>
            <label className="block text-slate-750 text-xs font-bold uppercase tracking-wider mb-2 font-mono flex items-center gap-1.5">
              <Hourglass className="w-4 h-4 text-lime-600" />
              Formato de Partidos
            </label>
            <div className="grid grid-cols-2 gap-3 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
              <button
                type="button"
                onClick={() => setFormat('Largo')}
                className={`py-2 px-4 text-xs font-bold rounded-lg transition text-center flex flex-col items-center justify-center ${
                  format === 'Largo'
                    ? 'bg-white border border-slate-200 text-slate-900 font-extrabold shadow-sm'
                    : 'text-slate-500 hover:text-slate-950'
                }`}
              >
                <span>Largo (3 Sets)</span>
              </button>
              <button
                type="button"
                onClick={() => setFormat('Mini')}
                className={`py-2 px-4 text-xs font-bold rounded-lg transition text-center flex flex-col items-center justify-center ${
                  format === 'Mini'
                    ? 'bg-white border border-slate-200 text-slate-900 font-extrabold shadow-sm'
                    : 'text-slate-500 hover:text-slate-955'
                }`}
              >
                <span>Mini (1 Set)</span>
              </button>
            </div>
          </div>

          {/* CTA Row */}
          <div className="flex flex-col sm:flex-row gap-3 justify-between items-stretch sm:items-center pt-4 border-t border-slate-100">
            {onDelete ? (
              <button
                type="button"
                onClick={() => {
                  if (confirm(`¿Estás seguro de que deseas eliminar el torneo "${tournament.name}"? Se perderán todos sus datos.`)) {
                    onDelete();
                  }
                }}
                className="px-4 py-2.5 rounded-xl text-rose-600 hover:text-white bg-rose-50 hover:bg-rose-600 border border-slate-200 hover:border-rose-600 font-extrabold text-xs transition cursor-pointer flex items-center justify-center gap-1.5 shadow-2xs"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Eliminar Torneo</span>
              </button>
            ) : (
              <div />
            )}
            <div className="flex gap-2 justify-end">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 hover:text-slate-900 text-xs font-extrabold transition cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-lime-500 hover:bg-lime-450 text-slate-950 text-xs font-extrabold shadow-2xs transition hover:scale-[1.01] cursor-pointer"
              >
                Guardar Cambios
              </button>
            </div>
          </div>

        </form>
      </div>
    </div>
  );
}
