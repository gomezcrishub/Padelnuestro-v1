import { Group, Pair, Match, TournamentFormat } from '../types';
import { calculateGroupStandings } from '../utils/tournamentSolver';
import { Edit2, Play, Trophy, Users } from 'lucide-react';

interface GroupStageViewProps {
  groups: Group[];
  pairs: Pair[];
  onGenerateGroups: () => void;
  onSelectMatch: (match: Match) => void;
  onAdvanceToPlayoffs: () => void;
  canAdvance: boolean;
  format?: TournamentFormat;
}

// Helper function to calculate and format match results badges for a pair
function getMatchBadges(group: Group, pairId: string, format: TournamentFormat = 'Largo') {
  const completedMatches = group.matches.filter(
    (m) => m.played && (m.teamAId === pairId || m.teamBId === pairId)
  );

  return completedMatches.map((match) => {
    const isTeamA = match.teamAId === pairId;
    
    // Determine win state
    const isWin = match.winnerId === pairId;

    // Calculate set scores
    let setsWon = 0;
    let setsLost = 0;
    let gamesWon = 0;
    let gamesLost = 0;

    // Set 1
    const s1A = match.set1 ? match.set1.teamA : 0;
    const s1B = match.set1 ? match.set1.teamB : 0;
    if (s1A > 0 || s1B > 0) {
      if (isTeamA) {
        gamesWon += s1A;
        gamesLost += s1B;
        if (s1A > s1B) setsWon++; else if (s1B > s1A) setsLost++;
      } else {
        gamesWon += s1B;
        gamesLost += s1A;
        if (s1B > s1A) setsWon++; else if (s1A > s1B) setsLost++;
      }
    }

    // Set 2
    const s2A = match.set2 ? match.set2.teamA : 0;
    const s2B = match.set2 ? match.set2.teamB : 0;
    if (s2A > 0 || s2B > 0) {
      if (isTeamA) {
        gamesWon += s2A;
        gamesLost += s2B;
        if (s2A > s2B) setsWon++; else if (s2B > s2A) setsLost++;
      } else {
        gamesWon += s2B;
        gamesLost += s2A;
        if (s2B > s2A) setsWon++; else if (s2A > s2B) setsLost++;
      }
    }

    // Set 3 (only in Largo)
    if (format === 'Largo') {
      const s3A = match.set3 ? match.set3.teamA : 0;
      const s3B = match.set3 ? match.set3.teamB : 0;
      if (s3A > 0 || s3B > 0) {
        if (isTeamA) {
          gamesWon += s3A;
          gamesLost += s3B;
          if (s3A > s3B) setsWon++; else if (s3B > s3A) setsLost++;
        } else {
          gamesWon += s3B;
          gamesLost += s3A;
          if (s3B > s3A) setsWon++; else if (s3A > s3B) setsLost++;
        }
      }
    }

    const setDiff = setsWon - setsLost;
    const gameDiff = gamesWon - gamesLost;

    // Format badge text
    let text = '';
    if (format === 'Mini') {
      // Mini format is 1 set, e.g. +4 or -4
      const sign = gameDiff > 0 ? '+' : '';
      text = `${sign}${gameDiff}`;
    } else {
      // Largo format, e.g. +2(+4) or -2(-4)
      const setSign = setDiff > 0 ? '+' : '';
      const gameSign = gameDiff > 0 ? '+' : '';
      text = `${setSign}${setDiff}(${gameSign}${gameDiff})`;
    }

    return {
      matchId: match.id,
      isWin,
      text,
      tooltip: `Sets: ${setsWon}-${setsLost}, Games: ${gamesWon}-${gamesLost}`
    };
  });
}

export default function GroupStageView({
  groups,
  pairs,
  onGenerateGroups,
  onSelectMatch,
  onAdvanceToPlayoffs,
  canAdvance,
  format = 'Largo',
}: GroupStageViewProps) {
  
  if (groups.length === 0) {
    return (
      <div className="bg-white border border-slate-200 p-8 rounded-2xl text-center flex flex-col items-center justify-center min-h-[350px] shadow-sm">
        <div className="w-16 h-16 rounded-full bg-slate-50 border border-slate-150 flex items-center justify-center text-3xl mb-4 shadow-inner">
          📊
        </div>
        <h3 className="text-slate-900 font-bold text-lg">Generar Fase de Grupos</h3>
        <p className="text-slate-500 text-sm max-w-md mt-2 mb-6">
          Tenemos {pairs.length} parejas inscriptas. Al generar la fase de grupos, el sistema organizará automáticamente las zonas de juego y creará el fixture de partidos correspondientes.
        </p>

        <button
          type="button"
          onClick={onGenerateGroups}
          disabled={pairs.length < 2}
          className="bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-bold px-6 py-3.5 rounded-xl text-sm transition shadow-sm flex items-center gap-2 cursor-pointer uppercase"
        >
          <Users className="w-4 h-4 text-white" />
          <span>Generar Fase de Grupos</span>
        </button>
        {pairs.length < 2 && (
          <p className="text-rose-600 text-xs mt-3">Se necesitan al menos 2 parejas inscriptas para iniciar grupos.</p>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-8 font-sans">
      
      {/* Advance to playoffs Callout Banner */}
      <div className="bg-white border border-slate-200 p-5 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div>
          <h3 className="text-slate-900 font-bold text-base flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-lime-500 animate-pulse"></span>
            Fase de Grupos en Curso
          </h3>
          <p className="text-slate-500 text-xs mt-1">
            Una vez finalizados los partidos de zona, puedes avanzar para armar los cruces de play-off directos.
          </p>
        </div>

        <button
          type="button"
          onClick={onAdvanceToPlayoffs}
          className={`px-5 py-2.5 text-xs font-bold rounded-xl transition ${
            canAdvance
              ? 'bg-lime-500 text-slate-900 hover:bg-lime-400 cursor-pointer shadow-sm'
              : 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
          }`}
        >
          Avanzar a Cuadro Eliminatorio →
        </button>
      </div>

      {/* Main Groups Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        {groups.map((group) => {
          const standings = calculateGroupStandings(group, pairs);
          
          return (
            <div key={group.id} className="bg-white border border-slate-200 rounded-2xl p-5 space-y-6 flex flex-col justify-between shadow-sm">
              
              {/* Header Group */}
              <div>
                <div className="flex justify-between items-center pb-3 border-b border-slate-150">
                  <h3 className="text-slate-900 font-bold text-lg flex items-center gap-2">
                    <span className="w-3 h-3 bg-lime-500 rounded-full" />
                    {group.name}
                  </h3>
                  <span className="text-slate-500 font-mono text-xs">{group.pairIds.length} parejas</span>
                </div>

                {/* Standings Table */}
                <div className="overflow-x-auto mt-4">
                  <table className="w-full text-left text-xs font-sans">
                    <thead>
                      <tr className="text-slate-400 font-bold uppercase tracking-wider border-b border-slate-100 text-[10px]">
                        <th className="py-2.5 w-8 text-center">Pos</th>
                        <th className="py-2.5">Pareja</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {standings.map((row, idx) => {
                        return (
                          <tr key={row.pairId} className="hover:bg-slate-50 text-slate-700 transition">
                            <td className="py-2.5 text-center">
                              <span className={`w-5 h-5 rounded-full inline-flex items-center justify-center font-mono text-[10px] font-bold ${
                                idx === 0 
                                  ? 'bg-yellow-100 text-yellow-800 border border-yellow-250' 
                                  : idx === 1
                                  ? 'bg-slate-100 text-slate-700 border border-slate-200'
                                  : 'bg-slate-50 text-slate-400'
                              }`}>
                                {idx + 1}
                              </span>
                            </td>
                             <td className="py-2.5 pr-2">
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 min-w-0">
                                <div className="flex flex-col gap-1 min-w-0 flex-1 py-0.5">
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-[9px] bg-lime-400/20 text-lime-800 px-1 rounded font-mono font-bold flex-shrink-0 w-3.5 text-center leading-normal">1</span>
                                    <span className="font-bold text-slate-900 text-xs truncate leading-none">{row.pair.player1}</span>
                                  </div>
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-[9px] bg-slate-200 text-slate-650 px-1 rounded font-mono font-bold flex-shrink-0 w-3.5 text-center leading-normal">2</span>
                                    <span className="text-slate-650 font-semibold text-xs truncate leading-none">{row.pair.player2}</span>
                                  </div>
                                </div>
                                <div className="flex flex-wrap gap-1 items-center shrink-0">
                                  {getMatchBadges(group, row.pairId, format).map((badge) => (
                                    <span
                                      key={badge.matchId}
                                      className={`inline-flex items-center justify-center font-extrabold px-1.5 py-0.5 rounded-full text-[9px] font-mono leading-none min-w-[28px] border shrink-0 transition shadow-2xs ${
                                        badge.isWin
                                          ? 'bg-emerald-50 text-emerald-700 border-emerald-250'
                                          : 'bg-rose-50 text-rose-700 border-rose-250'
                                      }`}
                                      title={badge.tooltip}
                                    >
                                      {badge.text}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Fixture / Matches in Group */}
              <div className="space-y-3 mt-4 border-t border-slate-150 pt-4">
                <h4 className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-3 font-mono">
                  Fixture & Resultados
                </h4>

                <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                  {group.matches.map((match) => {
                    const pairA = pairs.find(p => p.id === match.teamAId) || { player1: 'Pareja A', player2: '' };
                    const pairB = pairs.find(p => p.id === match.teamBId) || { player1: 'Pareja B', player2: '' };
                    const isWinnerA = match.winnerId === match.teamAId;
                    const isWinnerB = match.winnerId === match.teamBId;

                    return (
                      <div 
                        key={match.id}
                        className={`flex items-center justify-between p-3 rounded-xl border text-xs transition duration-150 ${
                          match.played 
                            ? 'bg-slate-50 border-slate-150' 
                            : 'bg-white hover:bg-slate-50 border-slate-200'
                        }`}
                      >
                        {/* Team A names */}
                        <div className={`flex-1 min-w-0 pr-2 ${isWinnerA ? 'text-slate-900 font-bold' : isWinnerB ? 'text-slate-400' : 'text-slate-700'}`}>
                          <p className="truncate font-sans font-medium text-sm">{pairA.player1}</p>
                          <p className={`text-[10px] truncate ${isWinnerA ? 'text-lime-600 font-semibold': 'text-slate-400'}`}>{pairA.player2}</p>
                        </div>

                        {/* Middle: Scores or Play CTA */}
                        {match.played ? (
                          <div 
                            onClick={() => onSelectMatch(match)}
                            className="flex flex-col items-center justify-center px-3 cursor-pointer hover:bg-slate-100 py-1 rounded transition border border-slate-200"
                          >
                            <div className="flex gap-1.5 font-mono font-bold text-center text-[11px] sm:text-xs">
                              <span className="flex items-center gap-0.5">
                                <span className={isWinnerA ? 'text-lime-650' : 'text-slate-500'}>{match.set1.teamA}</span>
                                <span className="text-slate-300 font-normal shadow-none">-</span>
                                <span className={isWinnerB ? 'text-lime-650' : 'text-slate-500'}>{match.set1.teamB}</span>
                              </span>
                              {format !== 'Mini' && (
                                <>
                                  <span className="text-slate-300">|</span>
                                  <span className="flex items-center gap-0.5">
                                    <span className={isWinnerA ? 'text-lime-650' : 'text-slate-500'}>{match.set2.teamA}</span>
                                    <span className="text-slate-300 font-normal shadow-none">-</span>
                                    <span className={isWinnerB ? 'text-lime-650' : 'text-slate-500'}>{match.set2.teamB}</span>
                                  </span>
                                </>
                              )}
                              {(match.set3.teamA > 0 || match.set3.teamB > 0) && (
                                <>
                                  <span className="text-slate-300">|</span>
                                  <span className="flex items-center gap-0.5">
                                    <span className="text-yellow-600">{match.set3.teamA}</span>
                                    <span className="text-slate-300 font-normal shadow-none">-</span>
                                    <span className="text-yellow-600">{match.set3.teamB}</span>
                                  </span>
                                </>
                              )}
                            </div>
                            <span className="text-[9px] text-slate-400 mt-0.5 flex items-center gap-1">
                              <Edit2 className="w-2.5 h-2.5" /> Editar
                            </span>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => onSelectMatch(match)}
                            className="bg-lime-50 hover:bg-lime-500 hover:text-slate-900 border border-lime-200 text-lime-700 px-3 py-1.5 rounded-lg flex items-center gap-1.5 font-semibold text-[10px] uppercase font-mono tracking-wider transition cursor-pointer"
                          >
                            <Play className="w-3 h-3 fill-current" />
                            Cargar
                          </button>
                        )}

                        {/* Team B names */}
                        <div className={`flex-1 min-w-0 pl-2 text-right ${isWinnerB ? 'text-slate-900 font-bold' : isWinnerA ? 'text-slate-400' : 'text-slate-700'}`}>
                          <p className="truncate font-sans font-medium text-sm">{pairB.player1}</p>
                          <p className={`text-[10px] truncate ${isWinnerB ? 'text-lime-600 font-semibold': 'text-slate-400'}`}>{pairB.player2}</p>
                        </div>

                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          );
        })}
      </div>
    </div>
  );
}
