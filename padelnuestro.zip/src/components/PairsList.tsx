import { useState, FormEvent } from 'react';
import { Pair, GroupMode } from '../types';
import { ChevronDown, ChevronUp, UserPlus } from 'lucide-react';

interface PairsListProps {
  pairs: Pair[];
  groupMode: GroupMode;
  onAddPair: (player1: string, player2: string) => void;
  onRemovePair: (id: string) => void;
  onReorderPairs: (newPairs: Pair[]) => void;
  onSetGroupMode: (mode: GroupMode) => void;
}

export default function PairsList({
  pairs,
  groupMode,
  onAddPair,
  onRemovePair,
  onReorderPairs,
  onSetGroupMode,
}: PairsListProps) {
  const [player1, setPlayer1] = useState('');
  const [player2, setPlayer2] = useState('');

  // States for inline editing of pairs
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editPlayer1, setEditPlayer1] = useState('');
  const [editPlayer2, setEditPlayer2] = useState('');

  const handleStartEdit = (id: string, p1: string, p2: string) => {
    setEditingId(id);
    setEditPlayer1(p1);
    setEditPlayer2(p2);
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditPlayer1('');
    setEditPlayer2('');
  };

  const handleSaveEdit = (id: string) => {
    if (!editPlayer1.trim() || !editPlayer2.trim()) return;
    const updated = pairs.map((p) => {
      if (p.id === id) {
        return { ...p, player1: editPlayer1.trim(), player2: editPlayer2.trim() };
      }
      return p;
    });
    onReorderPairs(updated);
    setEditingId(null);
  };

  const handleConfirmDelete = (id: string) => {
    onRemovePair(id);
    setEditingId(null);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!player1.trim() || !player2.trim()) return;
    onAddPair(player1.trim(), player2.trim());
    setPlayer1('');
    setPlayer2('');
  };

  const handleMoveUp = (index: number) => {
    if (index === 0) return;
    const reordered = [...pairs];
    const temp = reordered[index];
    reordered[index] = reordered[index - 1];
    reordered[index - 1] = temp;
    onReorderPairs(reordered);
  };

  const handleMoveDown = (index: number) => {
    if (index === pairs.length - 1) return;
    const reordered = [...pairs];
    const temp = reordered[index];
    reordered[index] = reordered[index + 1];
    reordered[index + 1] = temp;
    onReorderPairs(reordered);
  };

  return (
    <div className="space-y-6">
      
      {/* Group mode selector */}
      <div className="bg-white border border-slate-200 p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <h3 className="text-slate-900 font-bold text-base">Modalidad de Grupos</h3>
          <p className="text-slate-500 text-xs mt-1">
            Determina de cuántas parejas se compondrá cada grupo para el torneo.
          </p>
        </div>
        
        {/* Simple visual toggle button group as specified in the prompt: "Boton para seleccionar Modalidad de Grupos( 3 parejas o 4 parejas)" */}
        <div className="flex bg-slate-100 p-1 rounded-xl self-start sm:self-center border border-slate-200">
          <button
            type="button"
            onClick={() => onSetGroupMode('3 parejas')}
            className={`px-4 py-2 text-sm font-semibold rounded-lg font-sans transition-all leading-none ${
              groupMode === '3 parejas'
                ? 'bg-white text-slate-900 shadow-sm font-extrabold border border-slate-200'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            3 Parejas
          </button>
          <button
            type="button"
            onClick={() => onSetGroupMode('4 parejas')}
            className={`px-4 py-2 text-sm font-semibold rounded-lg font-sans transition-all leading-none ${
              groupMode === '4 parejas'
                ? 'bg-white text-slate-900 shadow-sm font-extrabold border border-slate-200'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            4 Parejas
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        
        {/* Left column: Add/Inscribe Pair Form */}
        <div className="lg:col-span-2 space-y-4 font-sans">
          <div className="bg-white border border-slate-200 p-5 rounded-2xl shadow-sm">
            <h3 className="text-slate-900 font-bold text-base flex items-center gap-2 mb-4">
              <UserPlus className="w-5 h-5 text-lime-650" />
              <span>Inscribir Pareja</span>
            </h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-slate-700 text-xs font-bold uppercase tracking-wider mb-1.5 font-mono">
                  Jugador 1
                </label>
                <input
                  type="text"
                  required
                  value={player1}
                  onChange={(e) => setPlayer1(e.target.value)}
                  placeholder="Ej: Alejandro Galán"
                  className="w-full bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-lime-500 focus:ring-1 focus:ring-lime-500 transition"
                />
              </div>

              <div>
                <label className="block text-slate-700 text-xs font-bold uppercase tracking-wider mb-1.5 font-mono">
                  Jugador 2
                </label>
                <input
                  type="text"
                  required
                  value={player2}
                  onChange={(e) => setPlayer2(e.target.value)}
                  placeholder="Ej: Juan Lebrón"
                  className="w-full bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-lime-500 focus:ring-1 focus:ring-lime-500 transition"
                />
              </div>

              <button
                type="submit"
                className="w-full mt-2 bg-lime-500 hover:bg-lime-400 text-slate-900 font-bold text-sm py-3 px-4 rounded-xl transition flex items-center justify-center gap-2 active:scale-95 cursor-pointer shadow-sm"
              >
                <span>Registrar Pareja</span>
              </button>
            </form>
          </div>
          
          <div className="bg-white p-4 rounded-xl border border-slate-200 text-slate-500 text-xs leading-relaxed space-y-1 shadow-sm">
            <p className="font-bold text-slate-700">💡 Cómo ordenar la lista:</p>
            <p>Usa las flechas de subir o bajar al lado de cada pareja para reordenar la siembra del torneo.</p>
          </div>
        </div>

        {/* Right column: Registered Pairs List */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-white border border-slate-200 p-5 rounded-2xl flex flex-col h-full min-h-[400px] shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-slate-900 font-bold text-base">
                Parejas Inscriptas ({pairs.length})
              </h3>
              {pairs.length > 0 && (
                <span className="text-xs bg-slate-100 text-slate-600 px-2.5 py-1 rounded-full font-mono font-medium border border-slate-200">
                  Orden de Siembra
                </span>
              )}
            </div>

            {pairs.length === 0 ? (
              <div className="flex flex-col items-center justify-center flex-1 text-center py-12">
                <div className="w-16 h-16 rounded-full bg-slate-50 border border-slate-150 flex items-center justify-center text-slate-350 mb-4 text-3xl">
                  🎾
                </div>
                <h4 className="text-slate-400 text-sm font-semibold">No hay parejas inscriptas</h4>
                <p className="text-slate-500 text-xs px-6 mt-1 max-w-sm">
                  Utiliza el formulario de la izquierda para registrar a los jugadores para el torneo.
                </p>
              </div>
            ) : (
              <div className="space-y-1.5 max-h-[480px] overflow-y-auto pr-1">
                {pairs.map((pair, index) => {
                  const isEditingThis = editingId === pair.id;

                  return (
                    <div
                      key={pair.id}
                      className={`relative flex items-center gap-2 p-2 rounded-xl border transition-all select-none group ${
                        isEditingThis
                          ? 'bg-white border-slate-300 shadow-md'
                          : 'bg-slate-50 hover:bg-slate-100/60 border-slate-200 text-slate-800'
                      }`}
                    >
                      {/* Number list identifier */}
                      <div className="w-5 h-5 rounded-full bg-white border border-slate-200 text-slate-650 text-[10px] font-bold font-mono flex items-center justify-center flex-shrink-0 font-extrabold shadow-3xs">
                        {index + 1}
                      </div>

                      {isEditingThis ? (
                        /* INLINE EDIT MODE FORM */
                        <div className="flex-1 min-w-0 py-1 px-1 space-y-2">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div>
                              <label className="block text-[9px] text-slate-500 font-bold uppercase tracking-wide mb-0.5">Jugador 1</label>
                              <input
                                type="text"
                                value={editPlayer1}
                                onChange={(e) => setEditPlayer1(e.target.value)}
                                className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-lg px-2 py-1 text-xs focus:outline-none focus:border-lime-500"
                              />
                            </div>
                            <div>
                              <label className="block text-[9px] text-slate-500 font-bold uppercase tracking-wide mb-0.5">Jugador 2</label>
                              <input
                                type="text"
                                value={editPlayer2}
                                onChange={(e) => setEditPlayer2(e.target.value)}
                                className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-lg px-2 py-1 text-xs focus:outline-none focus:border-lime-500"
                              />
                            </div>
                          </div>
                          <div className="flex justify-between items-center pt-1.5 border-t border-slate-100">
                            <button
                              type="button"
                              onClick={handleCancelEdit}
                              className="px-2 py-1 text-[10px] text-slate-500 hover:text-slate-800 font-extrabold"
                            >
                              Cancelar
                            </button>
                            <div className="flex gap-1.5">
                              <button
                                type="button"
                                onClick={() => handleConfirmDelete(pair.id)}
                                className="px-2 py-1 text-[10px] bg-rose-50 hover:bg-rose-100 text-rose-650 border border-rose-100 font-extrabold rounded-md shadow-2xs"
                              >
                                Borrar Pareja
                              </button>
                              <button
                                type="button"
                                onClick={() => handleSaveEdit(pair.id)}
                                className="px-2.5 py-1 text-[10px] bg-lime-500 hover:bg-lime-450 text-slate-950 font-extrabold rounded-md shadow-2xs"
                              >
                                Guardar
                              </button>
                            </div>
                          </div>
                        </div>
                      ) : (
                        /* PLAIN READ-ONLY DISPLAY */
                        <>
                          {/* Players info ordered for mobile screen */}
                          <div className="flex-1 min-w-0 py-0.5 pr-1 select-text">
                            <div className="flex flex-col gap-0.5">
                              <div className="flex items-center gap-1.5">
                                <span className="text-[9px] bg-lime-400/20 text-lime-800 px-1 rounded font-mono font-bold flex-shrink-0 w-3.5 text-center leading-none">1</span>
                                <p className="text-slate-900 text-xs font-bold truncate leading-none">
                                  {pair.player1}
                                </p>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <span className="text-[9px] bg-slate-200 text-slate-650 px-1 rounded font-mono font-bold flex-shrink-0 w-3.5 text-center leading-none">2</span>
                                <p className="text-slate-650 text-xs font-semibold truncate leading-none">
                                  {pair.player2}
                                </p>
                              </div>
                            </div>
                          </div>

                          {/* Controls */}
                          <div className="flex items-center gap-1 flex-shrink-0">
                            
                            {/* Up button */}
                            <button
                              type="button"
                              onClick={() => handleMoveUp(index)}
                              disabled={index === 0}
                              className={`p-1 rounded-md border transition-all ${
                                index === 0 
                                  ? 'text-slate-300 border-transparent cursor-not-allowed opacity-30'
                                  : 'text-slate-500 border-slate-250 hover:text-slate-950 hover:bg-white shadow-2xs'
                              }`}
                              title="Subir de posición"
                            >
                              <ChevronUp className="w-3.5 h-3.5" />
                            </button>

                            {/* Down button */}
                            <button
                              type="button"
                              onClick={() => handleMoveDown(index)}
                              disabled={index === pairs.length - 1}
                              className={`p-1 rounded-md border transition-all ${
                                index === pairs.length - 1
                                  ? 'text-slate-300 border-transparent cursor-not-allowed opacity-40'
                                  : 'text-slate-500 border-slate-250 hover:text-slate-950 hover:bg-white shadow-2xs'
                              }`}
                              title="Bajar de posición"
                            >
                              <ChevronDown className="w-3.5 h-3.5" />
                            </button>

                            {/* Edit button */}
                            <button
                              type="button"
                              onClick={() => handleStartEdit(pair.id, pair.player1, pair.player2)}
                              className="px-2 py-1 text-[10px] font-bold text-slate-600 hover:text-slate-950 bg-white border border-slate-200 hover:bg-slate-50 rounded-md transition shadow-2xs"
                              title="Editar pareja"
                            >
                              Editar
                            </button>

                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
