import { PlayoffBracket, Group, Pair, Match } from '../types';
import { Play, Trophy, Users, Edit2, RefreshCw } from 'lucide-react';
import { useState } from 'react';

interface PlayoffBracketViewProps {
  bracket: PlayoffBracket | null;
  groups: Group[];
  pairs: Pair[];
  onGenerateBracket: (size: '2' | '4' | '8' | '16') => void;
  onSelectMatch: (match: Match) => void;
  onUpdateMatchSeeding: (roundName: string, matchId: string, teamKey: 'teamAId' | 'teamBId', pairId: string) => void;
  onResetBracket: () => void;
}

export default function PlayoffBracketView({
  bracket,
  groups,
  pairs,
  onGenerateBracket,
  onSelectMatch,
  onUpdateMatchSeeding,
  onResetBracket,
}: PlayoffBracketViewProps) {
  const [selectedSize, setSelectedSize] = useState<'2' | '4' | '8' | '16'>('4');

  // If no bracket is generated, show the setup panel
  if (!bracket) {
    return (
      <div className="bg-white border border-slate-200 p-8 rounded-2xl text-center flex flex-col items-center justify-center min-h-[350px] shadow-sm font-sans">
        <div className="w-16 h-16 rounded-full bg-slate-50 border border-slate-150 flex items-center justify-center text-3xl mb-4 shadow-inner">
          🏆
        </div>
        <h3 className="text-slate-900 font-bold text-lg">Armar Cuadro Eliminatorio</h3>
        <p className="text-slate-500 text-sm max-w-md mt-2 mb-6">
          Configura y arma los cruces finales por eliminación directa (Playoffs). El sistema pre-seleccionará automáticamente a los clasificados según las tablas de posiciones del grupo.
        </p>

        <div className="w-full max-w-sm bg-slate-50 p-4 rounded-xl border border-slate-150 space-y-4 mb-6">
          <div className="text-left">
            <label className="block text-slate-650 text-[10px] font-bold uppercase font-mono tracking-wider mb-1.5">
              Tamaño del Cuadro (Fase Inicial)
            </label>
            <select
              value={selectedSize}
              onChange={(e) => setSelectedSize(e.target.value as '2' | '4' | '8' | '16')}
              className="w-full bg-white border border-slate-250 text-slate-900 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-lime-500 focus:ring-1 focus:ring-lime-500 transition shadow-sm"
            >
              <option value="2">Final Directa (2 Parejas)</option>
              <option value="4">Semifinales (4 Parejas)</option>
              <option value="8">Cuartos de Final (8 Parejas)</option>
            </select>
          </div>
        </div>

        <button
          type="button"
          onClick={() => onGenerateBracket(selectedSize)}
          disabled={pairs.length < parseInt(selectedSize, 10)}
          className="bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-bold px-6 py-3.5 rounded-xl text-sm transition shadow-sm flex items-center gap-2 cursor-pointer uppercase"
        >
          <Trophy className="w-4 h-4 text-white" />
          <span>Generar Cuadro de Eliminación</span>
        </button>
        
        {pairs.length < parseInt(selectedSize, 10) && (
          <p className="text-rose-650 text-xs mt-3">
            Se necesitan al menos {selectedSize} parejas registradas para generar este cuadro. (Tienes {pairs.length})
          </p>
        )}
      </div>
    );
  }

  // Find champion if the final match is played and has a winner
  const finalRound = bracket.rounds[bracket.rounds.length - 1];
  const finalMatch = finalRound?.matches[0];
  const championPair = finalMatch?.played && finalMatch.winnerId
    ? pairs.find(p => p.id === finalMatch.winnerId)
    : null;

  return (
    <div className="space-y-6 font-sans">
      
      {/* Header bar with controls */}
      <div className="bg-white border border-slate-200 p-4 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div>
          <h3 className="text-slate-900 font-bold text-sm flex items-center gap-2">
            <span>Cuadro Eliminatorio en Curso</span>
            {championPair && (
              <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-0.5 rounded font-mono font-bold flex items-center gap-1 border border-yellow-200/50 animate-pulse">
                🏆 ¡TENEMOS CAMPEÓN!
              </span>
            )}
          </h3>
          <p className="text-slate-500 text-xs mt-0.5">
            Los ganadores de cada llave avanzan automáticamente a la siguiente ronda del cuadro.
          </p>
        </div>

        <button
          onClick={onResetBracket}
          className="px-4 py-2 text-xs border border-slate-200 hover:bg-slate-50 text-slate-600 hover:text-slate-900 rounded-xl transition flex items-center gap-2 self-start md:self-center font-bold"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Reiniciar Cuadro</span>
        </button>
      </div>

      {/* Visual champion card */}
      {championPair && (
        <div className="bg-gradient-to-tr from-amber-50 via-white to-yellow-50/30 border-2 border-yellow-250 p-6 rounded-2xl text-center space-y-3 animate-fade-in shadow-sm">
          <div className="w-16 h-16 rounded-full bg-yellow-100 border border-yellow-350 flex items-center justify-center text-3xl mx-auto shadow-inner text-yellow-600 animate-bounce">
            🏆
          </div>
          <div>
            <h3 className="text-yellow-700 font-bold text-lg uppercase tracking-wider">¡Campeones del Torneo!</h3>
            <p className="text-slate-950 font-extrabold text-2xl mt-1.5">{championPair.player1} & {championPair.player2}</p>
            <p className="text-slate-500 text-xs mt-1">Felicitaciones a los ganadores de la gran final.</p>
          </div>
        </div>
      )}

      {/* Scrollable Layout for Bracket Tree */}
      <div className="overflow-x-auto pb-6">
        <div className="min-w-[800px] flex items-stretch gap-8 px-1 py-4">
          
          {bracket.rounds.map((round, rIndex) => {
            const isFirstRound = rIndex === 0;

            return (
              <div key={round.name} className="flex-1 flex flex-col justify-around min-h-[460px] space-y-4">
                
                {/* Round Header Name */}
                <div className="text-center pb-2 border-b border-slate-150 flex-shrink-0">
                  <h4 className="text-lime-700 font-extrabold text-sm uppercase tracking-wide font-mono">{round.name}</h4>
                  <p className="text-slate-500 text-[10px] mt-0.5">{round.matches.length} {round.matches.length === 1 ? 'partido' : 'partidos'}</p>
                </div>

                {/* Match boxes */}
                <div className="flex-1 flex flex-col justify-around gap-6">
                  {round.matches.map((match, mIndex) => {
                    const pairA = pairs.find(p => p.id === match.teamAId);
                    const pairB = pairs.find(p => p.id === match.teamBId);
                    const isWinnerA = match.winnerId === match.teamAId && match.played;
                    const isWinnerB = match.winnerId === match.teamBId && match.played;

                    return (
                      <div 
                        key={match.id}
                        className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm flex flex-col w-56 text-xs"
                      >
                        {/* Match Label */}
                        <div className="bg-slate-50 text-slate-500 px-3 py-1.5 text-[9px] uppercase font-mono border-b border-slate-150 flex justify-between items-center">
                          <span>Llave {mIndex + 1}</span>
                          {match.played && <span className="text-lime-700 font-bold">Jugado</span>}
                        </div>

                        {/* Teams score lines */}
                        <div className="p-2.5 space-y-2">
                          
                          {/* TEAM A LINE */}
                          <div className={`flex items-center justify-between gap-2.5 ${isWinnerB ? 'text-slate-400 opacity-80' : ''}`}>
                            <div className="flex-1 min-w-0">
                              {isFirstRound && !match.played ? (
                                // Show custom dropdown selector for manual seeding modifications during first round
                                <select
                                  value={match.teamAId || ''}
                                  onChange={(e) => onUpdateMatchSeeding(round.name, match.id, 'teamAId', e.target.value)}
                                  className="w-full bg-slate-50 text-slate-800 border border-slate-200 text-[10px] rounded px-1 py-0.5 font-sans focus:outline-none focus:border-lime-500"
                                >
                                  <option value="">-- Seleccionar --</option>
                                  {pairs.map((p, index) => (
                                    <option key={p.id} value={p.id}>
                                      {index + 1}. {p.player1} / {p.player2}
                                    </option>
                                  ))}
                                </select>
                              ) : (
                                <p className={`truncate font-bold text-sm ${isWinnerA ? 'text-lime-700' : 'text-slate-900'}`}>
                                  {pairA ? `${pairA.player1}` : 'Por clasificar'}
                                </p>
                              )}
                              {!isFirstRound && pairA && (
                                <p className="text-[10px] text-slate-500 truncate leading-none mt-0.5">
                                  {pairA.player2}
                                </p>
                              )}
                            </div>
                            
                            {/* Score Display (inline small box) */}
                            {match.played && pairA && (
                              <div className="flex gap-1 flex-shrink-0">
                                <span className={`inline-flex items-center justify-center w-5.5 h-5.5 rounded bg-slate-50 border border-slate-200 font-mono text-[10px] font-bold ${isWinnerA ? 'text-lime-700 bg-lime-500/10 border-lime-200' : 'text-slate-500'}`}>{match.set1.teamA}</span>
                                {match.set2 && (match.set2.teamA > 0 || match.set2.teamB > 0 || match.set3.teamA > 0 || match.set3.teamB > 0) && (
                                  <span className={`inline-flex items-center justify-center w-5.5 h-5.5 rounded bg-slate-50 border border-slate-200 font-mono text-[10px] font-bold ${isWinnerA ? 'text-lime-700 bg-lime-500/10 border-lime-200' : 'text-slate-500'}`}>{match.set2.teamA}</span>
                                )}
                                {match.set3 && (match.set3.teamA > 0 || match.set3.teamB > 0) && (
                                  <span className={`inline-flex items-center justify-center w-5.5 h-5.5 rounded bg-amber-50 border border-yellow-200 text-yellow-700 font-mono text-[10px] font-bold`}>{match.set3.teamA}</span>
                                )}
                              </div>
                            )}
                          </div>

                          <div className="h-[1px] bg-slate-100" />

                          {/* TEAM B LINE */}
                          <div className={`flex items-center justify-between gap-2.5 ${isWinnerA ? 'text-slate-400 opacity-80' : ''}`}>
                            <div className="flex-1 min-w-0">
                              {isFirstRound && !match.played ? (
                                <select
                                  value={match.teamBId || ''}
                                  onChange={(e) => onUpdateMatchSeeding(round.name, match.id, 'teamBId', e.target.value)}
                                  className="w-full bg-slate-50 text-slate-800 border border-slate-200 text-[10px] rounded px-1 py-0.5 font-sans focus:outline-none focus:border-lime-500"
                                >
                                  <option value="">-- Seleccionar --</option>
                                  {pairs.map((p, index) => (
                                    <option key={p.id} value={p.id}>
                                      {index + 1}. {p.player1} / {p.player2}
                                    </option>
                                  ))}
                                </select>
                              ) : (
                                <p className={`truncate font-bold text-sm ${isWinnerB ? 'text-lime-700' : 'text-slate-900'}`}>
                                  {pairB ? `${pairB.player1}` : 'Por clasificar'}
                                </p>
                              )}
                              {!isFirstRound && pairB && (
                                <p className="text-[10px] text-slate-500 truncate leading-none mt-0.5">
                                  {pairB.player2}
                                </p>
                              )}
                            </div>

                            {/* Score Display */}
                            {match.played && pairB && (
                              <div className="flex gap-1 flex-shrink-0">
                                <span className={`inline-flex items-center justify-center w-5.5 h-5.5 rounded bg-slate-50 border border-slate-200 font-mono text-[10px] font-bold ${isWinnerB ? 'text-lime-700 bg-lime-500/10 border-lime-200' : 'text-slate-500'}`}>{match.set1.teamB}</span>
                                {match.set2 && (match.set2.teamA > 0 || match.set2.teamB > 0 || match.set3.teamA > 0 || match.set3.teamB > 0) && (
                                  <span className={`inline-flex items-center justify-center w-5.5 h-5.5 rounded bg-slate-50 border border-slate-200 font-mono text-[10px] font-bold ${isWinnerB ? 'text-lime-700 bg-lime-500/10 border-lime-200' : 'text-slate-500'}`}>{match.set2.teamB}</span>
                                )}
                                {match.set3 && (match.set3.teamA > 0 || match.set3.teamB > 0) && (
                                  <span className={`inline-flex items-center justify-center w-5.5 h-5.5 rounded bg-amber-50 border border-yellow-200 text-yellow-700 font-mono text-[10px] font-bold`}>{match.set3.teamB}</span>
                                )}
                              </div>
                            )}
                          </div>

                        </div>

                        {/* CTA Play/Score buttons */}
                        {(!match.teamAId || !match.teamBId) ? (
                          <div className="bg-slate-50 text-slate-400 text-center py-2 text-[10px] border-t border-slate-150">
                            Esperando rivales
                          </div>
                        ) : match.played ? (
                          <button
                            type="button"
                            onClick={() => onSelectMatch(match)}
                            className="bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-900 text-center py-2 text-[10px] border-t border-slate-150 transition flex items-center justify-center gap-1.5 cursor-pointer font-bold"
                          >
                            <Edit2 className="w-3 h-3" />
                            <span>Editar Resultado</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => onSelectMatch(match)}
                            className="bg-lime-500 hover:bg-lime-400 text-slate-900 font-bold hover:text-black text-center py-2 text-[10px] border-t border-slate-150 transition flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <Play className="w-3 h-3 fill-current" />
                            <span>REGISTRAR SCORES</span>
                          </button>
                        )}

                      </div>
                    );
                  })}
                </div>

              </div>
            );
          })}
          
          {/* Champion Crown Podium Column */}
          <div className="w-48 flex-shrink-0 flex flex-col justify-center text-center border-l border-dashed border-slate-200 pl-8">
            <div className={`p-5 rounded-2xl border flex flex-col items-center justify-center space-y-3.5 transition-all duration-300 ${
              championPair 
                ? 'border-yellow-450 bg-amber-50/50 shadow-md shadow-yellow-500/5 shadow-sm' 
                : 'border-slate-200 bg-slate-50 opacity-40'
            }`}>
              <div className={`w-12 h-12 rounded-full flex items-center justify-center text-2xl ${
                championPair ? 'bg-yellow-100 text-yellow-600 animate-pulse border border-yellow-250' : 'bg-white text-slate-400'
              }`}>
                👑
              </div>
              <div>
                <h4 className="text-slate-500 uppercase tracking-wider font-mono text-[9px] font-bold">Campeón</h4>
                <p className="text-slate-900 font-extrabold text-sm line-clamp-2 mt-1">
                  {championPair ? `${championPair.player1}` : 'En juego'}
                </p>
                {championPair && (
                  <p className="text-lime-700 font-bold text-[10px] mt-0.5 truncate">{championPair.player2}</p>
                )}
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
