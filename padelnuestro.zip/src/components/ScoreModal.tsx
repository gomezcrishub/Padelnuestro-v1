import { Match, Pair } from '../types';
import { useState } from 'react';
import { Minus, Plus, Trophy, X } from 'lucide-react';

interface ScoreModalProps {
  match: Match;
  pairs: Pair[];
  format?: 'Largo' | 'Mini';
  onClose: () => void;
  onSave: (set1: { teamA: number; teamB: number }, set2: { teamA: number; teamB: number }, set3: { teamA: number; teamB: number }, winnerId: string | null) => void;
}

export default function ScoreModal({ match, pairs, format = 'Largo', onClose, onSave }: ScoreModalProps) {
  const teamA = pairs.find(p => p.id === match.teamAId) || { player1: 'Pareja A', player2: '' };
  const teamB = pairs.find(p => p.id === match.teamBId) || { player1: 'Pareja B', player2: '' };

  const [set1A, setSet1A] = useState(match.set1.teamA);
  const [set1B, setSet1B] = useState(match.set1.teamB);
  const [set2A, setSet2A] = useState(format === 'Mini' ? 0 : match.set2.teamA);
  const [set2B, setSet2B] = useState(format === 'Mini' ? 0 : match.set2.teamB);
  const [set3A, setSet3A] = useState(format === 'Mini' ? 0 : match.set3.teamA);
  const [set3B, setSet3B] = useState(format === 'Mini' ? 0 : match.set3.teamB);

  // Auto determine winner: winner is the one who wins 2 sets (Largo) or 1 set (Mini)
  const determineWinner = (): string | null => {
    if (format === 'Mini') {
      if (set1A > set1B) return match.teamAId;
      if (set1B > set1A) return match.teamBId;
      return null;
    }

    let setsA = 0;
    let setsB = 0;

    // Set 1 Winner
    if (set1A > set1B) setsA++;
    else if (set1B > set1A) setsB++;

    // Set 2 Winner
    if (set2A > set2B) setsA++;
    else if (set2B > set2A) setsB++;

    // Set 3 Winner
    if (set3A > set3B) setsA++;
    else if (set3B > set3A) setsB++;

    if (setsA >= 2) return match.teamAId;
    if (setsB >= 2) return match.teamBId;
    return null;
  };

  const calculatedWinner = determineWinner();

  const handleSave = () => {
    onSave(
      { teamA: set1A, teamB: set1B },
      { teamA: format === 'Mini' ? 0 : set2A, teamB: format === 'Mini' ? 0 : set2B },
      { teamA: format === 'Mini' ? 0 : set3A, teamB: format === 'Mini' ? 0 : set3B },
      calculatedWinner
    );
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in" id="score_modal">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl animate-scale-up font-sans" id="score_modal_body">
        
        {/* Header */}
        <div className="bg-slate-50 px-6 py-4 flex items-center justify-between border-b border-slate-200">
          <h3 className="text-lg font-bold text-slate-900">Registrar Resultado</h3>
          <button 
            type="button"
            onClick={onClose}
            className="text-slate-450 hover:text-slate-700 transition p-1.5 rounded-lg hover:bg-slate-200/50 cursor-pointer"
            id="close_modal_btn"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Competitors Summary */}
        <div className="bg-slate-50/50 px-6 py-5 flex justify-between items-center text-center gap-4 border-b border-slate-150">
          <div className="flex-1 min-w-0">
            <p className="text-lime-700 text-[10px] uppercase tracking-wider font-mono font-bold">Pareja A</p>
            <p className="text-slate-900 font-extrabold text-base mt-1 truncate">{teamA.player1}</p>
            <p className="text-slate-500 text-xs truncate">{teamA.player2}</p>
          </div>
          <div className="bg-white text-slate-500 font-mono text-xs px-2.5 py-1.5 rounded-lg border border-slate-200 shadow-sm font-bold">VS</div>
          <div className="flex-1 min-w-0">
            <p className="text-lime-700 text-[10px] uppercase tracking-wider font-mono font-bold">Pareja B</p>
            <p className="text-slate-900 font-extrabold text-base mt-1 truncate">{teamB.player1}</p>
            <p className="text-slate-500 text-xs truncate">{teamB.player2}</p>
          </div>
        </div>

        {/* Match Scores Scorer Container */}
        <div className="px-6 py-6 space-y-5">
          
          {/* SET 1 */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80">
            <div className="flex items-center justify-between mb-3">
              <span className="text-slate-600 text-xs font-mono font-extrabold uppercase tracking-wider">Set 1</span>
              {set1A !== set1B && (
                <span className="text-lime-750 text-[10px] bg-white px-2.5 py-0.5 rounded border border-slate-200 font-mono font-bold shadow-xs">
                  Ganador: {set1A > set1B ? 'Pareja A' : 'Pareja B'}
                </span>
              )}
            </div>
            
            <div className="flex items-center justify-between gap-6">
              {/* Pair A set 1 controller */}
              <div className="flex items-center gap-3">
                <button 
                  type="button"
                  onClick={() => setSet1A(prev => Math.max(0, prev - 1))}
                  className="w-8 h-8 rounded-full bg-white border border-slate-250 text-slate-600 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-center transition shadow-xs cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <div className="w-12 text-center text-2xl font-mono font-bold text-slate-905 bg-white py-1 rounded-lg border border-slate-200 shadow-inner">
                  {set1A}
                </div>
                <button 
                  type="button"
                  onClick={() => setSet1A(prev => Math.min(7, prev + 1))}
                  className="w-8 h-8 rounded-full bg-white border border-slate-250 text-slate-600 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-center transition shadow-xs cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              <div className="text-slate-400 font-bold">-</div>

              {/* Pair B set 1 controller */}
              <div className="flex items-center gap-3">
                <button 
                  type="button"
                  onClick={() => setSet1B(prev => Math.max(0, prev - 1))}
                  className="w-8 h-8 rounded-full bg-white border border-slate-250 text-slate-600 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-center transition shadow-xs cursor-pointer"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <div className="w-12 text-center text-2xl font-mono font-bold text-slate-905 bg-white py-1 rounded-lg border border-slate-200 shadow-inner">
                  {set1B}
                </div>
                <button 
                  type="button"
                  onClick={() => setSet1B(prev => Math.min(7, prev + 1))}
                  className="w-8 h-8 rounded-full bg-white border border-slate-250 text-slate-600 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-center transition shadow-xs cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {format === 'Largo' && (
            <>
              {/* SET 2 */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-slate-600 text-xs font-mono font-extrabold uppercase tracking-wider">Set 2</span>
                  {set2A !== set2B && (
                    <span className="text-lime-750 text-[10px] bg-white px-2.5 py-0.5 rounded border border-slate-200 font-mono font-bold shadow-xs">
                      Ganador: {set2A > set2B ? 'Pareja A' : 'Pareja B'}
                    </span>
                  )}
                </div>
                
                <div className="flex items-center justify-between gap-6">
                  {/* Pair A set 2 controller */}
                  <div className="flex items-center gap-3">
                    <button 
                      type="button"
                      onClick={() => setSet2A(prev => Math.max(0, prev - 1))}
                      className="w-8 h-8 rounded-full bg-white border border-slate-250 text-slate-600 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-center transition shadow-xs cursor-pointer"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <div className="w-12 text-center text-2xl font-mono font-bold text-slate-905 bg-white py-1 rounded-lg border border-slate-200 shadow-inner">
                      {set2A}
                    </div>
                    <button 
                      type="button"
                      onClick={() => setSet2A(prev => Math.min(7, prev + 1))}
                      className="w-8 h-8 rounded-full bg-white border border-slate-250 text-slate-600 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-center transition shadow-xs cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="text-slate-400 font-bold">-</div>

                  {/* Pair B set 2 controller */}
                  <div className="flex items-center gap-3">
                    <button 
                      type="button"
                      onClick={() => setSet2B(prev => Math.max(0, prev - 1))}
                      className="w-8 h-8 rounded-full bg-white border border-slate-250 text-slate-600 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-center transition shadow-xs cursor-pointer"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <div className="w-12 text-center text-2xl font-mono font-bold text-slate-905 bg-white py-1 rounded-lg border border-slate-200 shadow-inner">
                      {set2B}
                    </div>
                    <button 
                      type="button"
                      onClick={() => setSet2B(prev => Math.min(7, prev + 1))}
                      className="w-8 h-8 rounded-full bg-white border border-slate-250 text-slate-600 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-center transition shadow-xs cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* SET 3 */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-slate-600 text-xs font-mono font-extrabold uppercase tracking-wider flex items-center gap-1">
                    Set 3 <span className="text-[9px] text-lime-700 capitalize font-mono">(Super Tiebreak / Desempate)</span>
                  </span>
                  {set3A !== set3B && (
                    <span className="text-lime-750 text-[10px] bg-white px-2.5 py-0.5 rounded border border-slate-200 font-mono font-bold shadow-xs">
                      Ganador: {set3A > set3B ? 'Pareja A' : 'Pareja B'}
                    </span>
                  )}
                </div>
                
                <div className="flex items-center justify-between gap-6">
                  {/* Pair A set 3 controller */}
                  <div className="flex items-center gap-3">
                    <button 
                      type="button"
                      onClick={() => setSet3A(prev => Math.max(0, prev - 1))}
                      className="w-8 h-8 rounded-full bg-white border border-slate-250 text-slate-600 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-center transition shadow-xs cursor-pointer"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <div className="w-12 text-center text-2xl font-mono font-bold text-slate-905 bg-white py-1 rounded-lg border border-slate-200 shadow-inner">
                      {set3A}
                    </div>
                    <button 
                      type="button"
                      onClick={() => setSet3A(prev => Math.min(20, prev + 1))}
                      className="w-8 h-8 rounded-full bg-white border border-slate-250 text-slate-600 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-center transition shadow-xs cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="text-slate-400 font-bold">-</div>

                  {/* Pair B set 3 controller */}
                  <div className="flex items-center gap-3">
                    <button 
                      type="button"
                      onClick={() => setSet3B(prev => Math.max(0, prev - 1))}
                      className="w-8 h-8 rounded-full bg-white border border-slate-250 text-slate-600 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-center transition shadow-xs cursor-pointer"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <div className="w-12 text-center text-2xl font-mono font-bold text-slate-905 bg-white py-1 rounded-lg border border-slate-200 shadow-inner">
                      {set3B}
                    </div>
                    <button 
                      type="button"
                      onClick={() => setSet3B(prev => Math.min(20, prev + 1))}
                      className="w-8 h-8 rounded-full bg-white border border-slate-250 text-slate-600 hover:bg-slate-50 hover:text-slate-900 flex items-center justify-center transition shadow-xs cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* Winner banner announcement */}
          <div className="flex items-center justify-center gap-2 p-3.5 bg-slate-50 rounded-xl border border-slate-150 text-center shadow-xs">
            {calculatedWinner ? (
              <div className="flex items-center gap-2 text-lime-800 font-bold text-sm">
                <Trophy className="w-4 h-4 text-amber-500 fill-current animate-pulse" />
                <span>
                  Ganador: {calculatedWinner === match.teamAId ? `${teamA.player1}` : `${teamB.player1}`}
                </span>
              </div>
            ) : (
              <span className="text-slate-500 text-xs font-medium">
                {format === 'Mini'
                  ? 'El ganador del partido se determinará al registrar diferencia de games en el set.'
                  : 'El ganador del partido se determinará automáticamente al ganar 2 sets.'}
              </span>
            )}
          </div>

        </div>

        {/* Action buttons footer */}
        <div className="bg-slate-50 px-6 py-4 flex items-center justify-end gap-3 border-t border-slate-250">
          <button 
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-900 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition cursor-pointer shadow-xs"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={calculatedWinner === null && (set1A !== 0 || set1B !== 0)} 
            className="px-5 py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-40 rounded-xl transition cursor-pointer shadow-sm uppercase tracking-wider"
          >
            Guardar Resultado
          </button>
        </div>

      </div>
    </div>
  );
}
