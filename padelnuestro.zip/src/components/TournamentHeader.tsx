import { Tournament } from '../types';
import { Award, Edit2, Trash2, Trophy, Users } from 'lucide-react';

interface TournamentHeaderProps {
  tournament: Tournament;
  onDelete: () => void;
  onEdit: () => void;
  activeStage: 'registration' | 'groups' | 'playoffs';
  onSetStage: (stage: 'registration' | 'groups' | 'playoffs') => void;
}

export default function TournamentHeader({
  tournament,
  onDelete,
  onEdit,
  activeStage,
  onSetStage,
}: TournamentHeaderProps) {
  
  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
      
      {/* Primary Row: Name & Badges & Close action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        
        <div className="space-y-2">
          {/* Badges capsule list */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[10px] font-bold font-mono tracking-wider text-lime-700 bg-lime-500/10 px-2.5 py-1 rounded-full border border-lime-500/20 uppercase">
              🏆 {tournament.category}
            </span>
            <span className="text-[10px] font-bold font-mono tracking-wider text-cyan-700 bg-cyan-500/10 px-2.5 py-1 rounded-full border border-cyan-500/20 uppercase">
              {tournament.type === 'CABALLEROS' ? 'Caballeros' : tournament.type === 'DAMAS' ? 'Damas' : 'Mixto'}
            </span>
            <span className="text-[10px] font-bold font-mono tracking-wider text-slate-600 bg-slate-100 px-2.5 py-1 rounded-full border border-slate-200 uppercase">
              👥 {tournament.groupMode}
            </span>
          </div>

          {/* Tournament Name */}
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight leading-tight">
            {tournament.name}
          </h1>
        </div>

        {/* Action button CTAs Group */}
        <div className="flex flex-wrap items-center gap-2 self-start sm:self-center">
          
          {/* Edit button */}
          <button
            type="button"
            onClick={onEdit}
            className="flex items-center gap-1.5 text-xs text-slate-700 hover:text-white hover:bg-slate-800 border border-slate-300 hover:border-slate-800 px-3.5 py-2 rounded-xl transition cursor-pointer font-bold bg-white shadow-2xs"
            title="Editar torneo actual"
          >
            <Edit2 className="w-3.5 h-3.5" />
            <span>Editar Torneo</span>
          </button>
        </div>

      </div>

      {/* Secondary Row: Step Navigation Wizard Tabs */}
      <div className="flex p-1 bg-slate-100 rounded-xl border border-slate-200 max-w-lg">
        {/* Registration Tab button */}
        <button
          type="button"
          onClick={() => onSetStage('registration')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold rounded-lg transition-all ${
            activeStage === 'registration'
              ? 'bg-slate-800 text-white shadow-sm font-extrabold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>1. Inscriptos</span>
        </button>

        {/* Group Stage Tab button */}
        <button
          type="button"
          onClick={() => onSetStage('groups')}
          disabled={tournament.pairs.length === 0}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold rounded-lg transition-all ${
            tournament.pairs.length === 0 ? 'opacity-40 cursor-not-allowed' : ''
          } ${
            activeStage === 'groups'
              ? 'bg-slate-800 text-white shadow-sm font-extrabold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Award className="w-3.5 h-3.5" />
          <span>2. Grupos</span>
        </button>

        {/* Playoff stage button */}
        <button
          type="button"
          onClick={() => onSetStage('playoffs')}
          disabled={tournament.pairs.length === 0}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold rounded-lg transition-all ${
            tournament.pairs.length === 0 ? 'opacity-40 cursor-not-allowed' : ''
          } ${
            activeStage === 'playoffs'
              ? 'bg-slate-800 text-white shadow-sm font-extrabold'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Trophy className="w-3.5 h-3.5" />
          <span>3. Playoffs</span>
        </button>
      </div>

    </div>
  );
}
