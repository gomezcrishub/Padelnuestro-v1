import { Pair, Group, Match, SetScore, PlayoffBracket, PlayoffRound, GroupMode } from '../types';

export interface StandingRow {
  pairId: string;
  pair: Pair;
  points: number; // 3 for win, 1 for played/lost (often 2 pts win, 1 pt loss, let's use standard: PG*3 for maximum contrast)
  played: number;
  won: number;
  lost: number;
  setsWon: number;
  setsLost: number;
  setsDiff: number;
  gamesWon: number;
  gamesLost: number;
  gamesDiff: number;
}

// Helper to generate a unique random ID
export function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}

// Generate circular or standard matches for a group of pairs
export function generateGroupMatches(pairIds: string[], groupName: string): Match[] {
  const matches: Match[] = [];
  const n = pairIds.length;

  if (n < 2) return [];

  // Round Robin generation
  // For 3 pairs (A, B, C): A vs B, B vs C, A vs C
  // For 4 pairs (A, B, C, D): A vs B, C vs D, A vs C, B vs D, A vs D, B vs C
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      matches.push({
        id: `match_${groupName.replace(/\s+/g, '')}_${i}_${j}_${generateId()}`,
        teamAId: pairIds[i],
        teamBId: pairIds[j],
        set1: { teamA: 0, teamB: 0 },
        set2: { teamA: 0, teamB: 0 },
        set3: { teamA: 0, teamB: 0 },
        winnerId: null,
        played: false,
        roundName: groupName,
      });
    }
  }

  return matches;
}

// Distributes pairs into groups balanced by size
export function generateGroups(pairs: Pair[], groupMode: GroupMode): Group[] {
  if (pairs.length === 0) return [];

  const targetSize = groupMode === '3 parejas' ? 3 : 4;
  
  // Calculate recommended number of groups, at least 1
  let numGroups = Math.floor(pairs.length / targetSize);
  if (numGroups < 1) {
    numGroups = 1;
  }

  // If we have remaining pairs, distribute them. Let's make sure that groups are as balanced as possible.
  // We initialize the groups array
  const groups: Group[] = Array.from({ length: numGroups }, (_, i) => {
    const letter = String.fromCharCode(65 + i); // A, B, C, D...
    return {
      id: `group_${letter.toLowerCase()}_${generateId()}`,
      name: `Grupo ${letter}`,
      pairIds: [],
      matches: []
    };
  });

  // Distribute pairs using Snake Seeding or Sequential seeding
  // To avoid confusion, Sequential distribution puts consecutives if they want,
  // but Snake seeding (e.g. Group A, B, B, A) is very professional. Let's use simple sequential round-robin:
  // Pair 1 -> Group A, Pair 2 -> Group B, Pair 3 -> Group C, Pair 4 -> Group C, etc.
  pairs.forEach((pair, index) => {
    const groupIndex = index % numGroups;
    groups[groupIndex].pairIds.push(pair.id);
  });

  // Generate matches for each group
  groups.forEach(group => {
    group.matches = generateGroupMatches(group.pairIds, group.name);
  });

  return groups;
}

// Calculate standinds for a single group
export function calculateGroupStandings(group: Group, pairs: Pair[]): StandingRow[] {
  const standingsMap: Record<string, StandingRow> = {};

  // Initialize standings row for each pair in the group
  group.pairIds.forEach(pairId => {
    const pair = pairs.find(p => p.id === pairId) || { id: pairId, player1: 'Desconocido', player2: 'Desconocido', registeredAt: 0 };
    standingsMap[pairId] = {
      pairId,
      pair,
      points: 0,
      played: 0,
      won: 0,
      lost: 0,
      setsWon: 0,
      setsLost: 0,
      setsDiff: 0,
      gamesWon: 0,
      gamesLost: 0,
      gamesDiff: 0,
    };
  });

  // Process completed matches in the group
  group.matches.forEach(match => {
    if (!match.played || !match.winnerId) return;

    const teamA = match.teamAId;
    const teamB = match.teamBId;

    // Ensure we have entries in the map
    if (!standingsMap[teamA] || !standingsMap[teamB]) return;

    const rowA = standingsMap[teamA];
    const rowB = standingsMap[teamB];

    // Update matches played
    rowA.played += 1;
    rowB.played += 1;

    // Calculate Sets and Games
    let setsA = 0;
    let setsB = 0;
    let gamesA = 0;
    let gamesB = 0;

    // Set 1
    gamesA += match.set1.teamA;
    gamesB += match.set1.teamB;
    if (match.set1.teamA > match.set1.teamB) setsA++;
    else if (match.set1.teamB > match.set1.teamA) setsB++;

    // Set 2
    gamesA += match.set2.teamA;
    gamesB += match.set2.teamB;
    if (match.set2.teamA > match.set2.teamB) setsA++;
    else if (match.set2.teamB > match.set2.teamA) setsB++;

    // Set 3 (if played)
    const hasSet3 = match.set3.teamA > 0 || match.set3.teamB > 0;
    if (hasSet3) {
      gamesA += match.set3.teamA;
      gamesB += match.set3.teamB;
      if (match.set3.teamA > match.set3.teamB) setsA++;
      else if (match.set3.teamB > match.set3.teamA) setsB++;
    }

    rowA.setsWon += setsA;
    rowA.setsLost += setsB;
    rowB.setsWon += setsB;
    rowB.setsLost += setsA;

    rowA.gamesWon += gamesA;
    rowA.gamesLost += gamesB;
    rowB.gamesWon += gamesB;
    rowB.gamesLost += gamesA;

    // Update winner and loser records
    if (match.winnerId === teamA) {
      rowA.won += 1;
      rowA.points += 3; // 3 pts for victory
      rowB.lost += 1;
      rowB.points += 1; // 1 pt for play
    } else {
      rowB.won += 1;
      rowB.points += 3;
      rowA.lost += 1;
      rowA.points += 1;
    }
  });

  // Convert map to array and compute differences
  const standingsList = Object.values(standingsMap).map(row => {
    row.setsDiff = row.setsWon - row.setsLost;
    row.gamesDiff = row.gamesWon - row.gamesLost;
    return row;
  });

  // Sort standings:
  // 1. Matches Won (won)
  // 2. SetsDifference (setsDiff)
  // 3. GamesDifference (gamesDiff)
  return standingsList.sort((a, b) => {
    if (b.won !== a.won) return b.won - a.won;
    if (b.setsDiff !== a.setsDiff) return b.setsDiff - a.setsDiff;
    return b.gamesDiff - a.gamesDiff;
  });
}

// Logic to generate the initial playoff bracket
export function generateInitialBracket(
  size: '2' | '4' | '8' | '16',
  groups: Group[],
  pairs: Pair[]
): PlayoffBracket {
  const rounds: PlayoffRound[] = [];
  const sizeNum = parseInt(size, 10);

  // Determine rounds: E.g., if sizeNum is 8, we have Cuartos (8), Semifinal (4), Final (2)
  // Let's build the rounds list backwards or forwards
  let currentSize = sizeNum;
  
  // Calculate qualifiers dynamically from groups
  const groupStandings = groups.map(g => ({
    groupName: g.name,
    standings: calculateGroupStandings(g, pairs)
  }));

  // We find standard automatic qualifiers:
  // E.g., if size is 4 (Semifinals) and there are 2 groups (A, B)
  // Slot 1: Semifinal A (1st Group A vs 2nd Group B)
  // Slot 2: Semifinal B (1st Group B vs 2nd Group A)
  const getAutoQualifier = (groupLetter: string, position: 1 | 2): string => {
    const targetGroup = groupStandings.find(g => g.groupName.endsWith(groupLetter));
    if (targetGroup && targetGroup.standings[position - 1]) {
      return targetGroup.standings[position - 1].pairId;
    }
    return '';
  };

  while (currentSize >= 2) {
    let roundName = '';
    if (currentSize === 16) roundName = 'Octavos de Final';
    else if (currentSize === 8) roundName = 'Cuartos de Final';
    else if (currentSize === 4) roundName = 'Semifinales';
    else if (currentSize === 2) roundName = 'Final';

    const matchesCount = currentSize / 2;
    const matches: Match[] = [];

    for (let i = 0; i < matchesCount; i++) {
      let teamAId = '';
      let teamBId = '';

      // Auto-seeding heuristic based on typical brackets, only for the first round of the bracket
      if (currentSize === sizeNum) {
        if (sizeNum === 2) {
          // Final: 1st Group A vs 1st Group B (if 2 groups exist)
          teamAId = getAutoQualifier('A', 1);
          teamBId = getAutoQualifier('B', 1) || getAutoQualifier('A', 2);
        } else if (sizeNum === 4) {
          // Semifinal 1: 1st A vs 2nd B
          // Semifinal 2: 1st B vs 2nd A
          if (i === 0) {
            teamAId = getAutoQualifier('A', 1);
            teamBId = getAutoQualifier('B', 2);
          } else {
            teamAId = getAutoQualifier('B', 1);
            teamBId = getAutoQualifier('A', 2);
          }
        } else if (sizeNum === 8) {
          // QF 1: 1st A vs 2nd B
          // QF 2: 1st C vs 2nd D
          // QF 3: 1st B vs 2nd A
          // QF 4: 1st D vs 2nd C
          if (i === 0) {
            teamAId = getAutoQualifier('A', 1);
            teamBId = getAutoQualifier('B', 2);
          } else if (i === 1) {
            teamAId = getAutoQualifier('C', 1);
            teamBId = getAutoQualifier('D', 2);
          } else if (i === 2) {
            teamAId = getAutoQualifier('B', 1);
            teamBId = getAutoQualifier('A', 2);
          } else if (i === 3) {
            teamAId = getAutoQualifier('D', 1);
            teamBId = getAutoQualifier('C', 2);
          }
        }
      }

      matches.push({
        id: `playoff_${roundName ? roundName.replace(/\s+/g, '') : 'Round'}_${i}_${generateId()}`,
        teamAId,
        teamBId,
        set1: { teamA: 0, teamB: 0 },
        set2: { teamA: 0, teamB: 0 },
        set3: { teamA: 0, teamB: 0 },
        winnerId: null,
        played: false,
        roundName,
      });
    }

    rounds.push({
      name: roundName,
      matches,
    });

    currentSize /= 2;
  }

  return { rounds };
}

// Advances bracket winners to the correct spot in the next round
export function advanceBracketWinner(
  bracket: PlayoffBracket,
  matchId: string,
  winnerId: string | null,
  set1?: SetScore,
  set2?: SetScore,
  set3?: SetScore
): PlayoffBracket {
  const newRounds = JSON.parse(JSON.stringify(bracket.rounds)) as PlayoffRound[];
  
  // Find which round and match indexing we are in
  let roundIdx = -1;
  let matchIdx = -1;

  for (let r = 0; r < newRounds.length; r++) {
    const mIdx = newRounds[r].matches.findIndex(m => m.id === matchId);
    if (mIdx !== -1) {
      roundIdx = r;
      matchIdx = mIdx;
      // Update winner of this specific match
      newRounds[r].matches[mIdx].winnerId = winnerId;
      newRounds[r].matches[mIdx].played = winnerId !== null;
      if (set1) newRounds[r].matches[mIdx].set1 = set1;
      if (set2) newRounds[r].matches[mIdx].set2 = set2;
      if (set3) newRounds[r].matches[mIdx].set3 = set3;
      break;
    }
  }

  if (roundIdx === -1 || matchIdx === -1) return { rounds: newRounds };

  // If there is a next round (e.g. current round is not the Final which is the last item in rounds)
  const nextRoundIdx = roundIdx + 1;
  if (nextRoundIdx < newRounds.length) {
    const nextMatchIdx = Math.floor(matchIdx / 2);
    const isTeamA = matchIdx % 2 === 0;

    if (isTeamA) {
      newRounds[nextRoundIdx].matches[nextMatchIdx].teamAId = winnerId || '';
    } else {
      newRounds[nextRoundIdx].matches[nextMatchIdx].teamBId = winnerId || '';
    }

    // Also clear subsequent matches' winner state if previous winner changes
    const propagateClear = (currRIdx: number, currMIdx: number) => {
      const nextR = currRIdx + 1;
      if (nextR < newRounds.length) {
        const nextM = Math.floor(currMIdx / 2);
        const isNextA = currMIdx % 2 === 0;
        
        // Reset results in future rounds
        newRounds[nextR].matches[nextM].played = false;
        newRounds[nextR].matches[nextM].winnerId = null;
        newRounds[nextR].matches[nextM].set1 = { teamA: 0, teamB: 0 };
        newRounds[nextR].matches[nextM].set2 = { teamA: 0, teamB: 0 };
        newRounds[nextR].matches[nextM].set3 = { teamA: 0, teamB: 0 };

        propagateClear(nextR, nextM);
      }
    };

    propagateClear(roundIdx, matchIdx);
  }

  return { rounds: newRounds };
}
